# Deploying FinSentry to Databricks

This walks through taking the project from "runs locally" to "runs as a
governed, production Databricks app." Do the steps in order -- each one
unlocks the next layer of the architecture.

Prerequisites: a Databricks workspace on a plan that supports Unity Catalog,
Vector Search, Model Serving, Lakebase, and Databricks Apps (Premium/
Enterprise, or a region-supported Free Edition for a quick test), and the
Databricks CLI (`databricks -v` >= 0.229.0) authenticated to that workspace.

---

## 1. Unity Catalog: catalog, schema, and raw file landing zone

```sql
CREATE CATALOG IF NOT EXISTS finsentry;
CREATE SCHEMA IF NOT EXISTS finsentry.spend_analytics;
```

Create a Volume to land the raw CSVs and the RAG source documents:

```sql
CREATE VOLUME IF NOT EXISTS finsentry.spend_analytics.raw_files;
```

Upload the files (CLI, or drag-and-drop in the Catalog Explorer UI):

```bash
databricks fs cp data/raw/departments.csv   dbfs:/Volumes/finsentry/spend_analytics/raw_files/departments.csv
databricks fs cp data/raw/categories.csv    dbfs:/Volumes/finsentry/spend_analytics/raw_files/categories.csv
databricks fs cp data/raw/vendors.csv       dbfs:/Volumes/finsentry/spend_analytics/raw_files/vendors.csv
databricks fs cp data/raw/transactions.csv  dbfs:/Volumes/finsentry/spend_analytics/raw_files/transactions.csv
databricks fs cp data/raw/budgets.csv       dbfs:/Volumes/finsentry/spend_analytics/raw_files/budgets.csv
databricks fs cp docs/policy_procurement.txt               dbfs:/Volumes/finsentry/spend_analytics/raw_files/policy_procurement.txt
databricks fs cp docs/vendor_contracts_summary.txt          dbfs:/Volumes/finsentry/spend_analytics/raw_files/vendor_contracts_summary.txt
databricks fs cp docs/quarterly_spend_narrative_2025q3.txt   dbfs:/Volumes/finsentry/spend_analytics/raw_files/quarterly_spend_narrative_2025q3.txt
```

(In a real deployment these CSVs would instead land here via your existing
ERP/procurement system extract -- an Auto Loader job or a Lakeflow/DLT
pipeline reading from cloud storage is the natural next step once this is
no longer demo data.)

## 2. Run the pipeline notebook

Import `pipeline/databricks_pipeline.py` into your workspace as a notebook
(File > Import, or `databricks workspace import`). Attach it to a
general-purpose cluster or use serverless notebooks, then:

```
%pip install databricks-vectorsearch
dbutils.library.restartPython()
```

as the first cell, then **Run All**. It builds Bronze -> Silver -> Gold and
creates the Vector Search endpoint + index. You can override the widget
defaults (`catalog`, `schema`, `volume_path`) at the top if you used
different names.

To run it on a schedule instead of manually, turn it into a **Databricks
Workflow** (Workflows > Create Job > Notebook task pointing at this
notebook) -- this is the "Workflows" box in the architecture diagram, and
it's how you'd refresh the Gold tables nightly against real transaction
data.

## 3. Model Serving

Databricks Foundation Model APIs are enabled by default in most workspaces
-- no setup needed to call `databricks-meta-llama-3-3-70b-instruct` (the
default in `app/model_client.py`). If you'd rather serve Claude:

```python
from mlflow.deployments import get_deploy_client
client = get_deploy_client("databricks")
client.create_endpoint(
    name="finsentry-claude",
    config={"served_entities": [{
        "name": "claude",
        "external_model": {
            "name": "claude-sonnet-4-6", "provider": "anthropic", "task": "llm/v1/chat",
            "anthropic_config": {"anthropic_api_key": "{{secrets/finsentry/anthropic_key}}"},
        },
    }]},
)
```

Then set `DATABRICKS_SERVING_MODEL=finsentry-claude` as an app environment
variable.

## 4. Lakebase (agent memory)

Provision a Lakebase Postgres instance for the app's conversation memory:

```bash
databricks postgres create-project finsentry-memory
```

Databricks Apps can attach a Lakebase resource directly and injects the
connection string automatically -- add it as a resource when you create the
app in step 6, or set `LAKEBASE_CONNECTION_STRING` yourself as an app
secret if you're wiring it up manually. `app/memory_store.py` picks it up
with no code changes; without it, the app falls back to local SQLite.

For production LangGraph deployments, swap the hand-rolled queries in
`memory_store.py` for `langgraph-checkpoint-postgres` against the same
Lakebase instance -- that gets you native LangGraph thread checkpointing
(resume a conversation mid-graph) instead of just append-only history.

## 5. Unity Catalog governance

The app-level role check in `agents.py` (`check_permission`) is a
convenience layer for tailoring what the agent discusses per role. The real
enforcement belongs on the tables themselves:

```sql
GRANT SELECT ON TABLE finsentry.spend_analytics.gold_spend_by_category_month TO `analysts`;
GRANT SELECT ON TABLE finsentry.spend_analytics.gold_savings_opportunities TO `finance_leads`;

-- Example row filter restricting a group to categories they own:
CREATE OR REPLACE FUNCTION finsentry.spend_analytics.category_row_filter(category_name STRING)
RETURN IS_ACCOUNT_GROUP_MEMBER('finance_leads') OR category_name IN ('IT & Software', 'Professional Services');

ALTER TABLE finsentry.spend_analytics.gold_spend_by_category_month
SET ROW FILTER finsentry.spend_analytics.category_row_filter ON (category_name);
```

Lineage from `bronze_transactions` through to `gold_savings_opportunities`
is automatic in Unity Catalog -- check the Catalog Explorer "Lineage" tab
once the pipeline has run once.

## 6. Deploy the Streamlit app to Databricks Apps

From the `app/` folder:

```bash
databricks apps create --name finsentry-app
databricks apps deploy finsentry-app --source-code-path .
```

Set the required environment variables/secrets on the app (Databricks Apps
UI > your app > Environment, or via a `databricks.yml` asset bundle):

| Variable | Value |
|---|---|
| `DATABRICKS_HOST` | your workspace hostname (Apps usually inject this automatically) |
| `DATABRICKS_TOKEN` | a service-principal PAT scoped to this app |
| `DATABRICKS_HTTP_PATH` | your SQL Warehouse's HTTP path |
| `LAKEBASE_CONNECTION_STRING` | from step 4 (or attach Lakebase as an app resource) |
| `FINSENTRY_CATALOG` / `FINSENTRY_SCHEMA` | `finsentry` / `spend_analytics` (already in `app.yaml`) |

Grant the app's service principal `USE CATALOG`, `USE SCHEMA`, and `SELECT`
on the Gold tables, plus query access to the Vector Search index and the
Model Serving endpoint.

Once deployed, Databricks Apps gives you a URL -- that's your production
"Databricks Apps" box from the architecture diagram, running the same
`streamlit_app.py` you tested locally, now backed by real Unity Catalog
data, Vector Search, Model Serving, and Lakebase.

## 7. Observability

Every agent run already produces a structured `trace` (see the "How this
answer was produced" expander in the app). To ship that to Lakehouse
Monitoring / an audit table instead of just holding it in memory, add one
more Gold-adjacent table:

```sql
CREATE TABLE IF NOT EXISTS finsentry.spend_analytics.agent_traces (
    session_id STRING, ts DOUBLE, agent STRING, message STRING
);
```

and have `action_agent` in `agents.py` write `state["trace"].events` there
via `spark.createDataFrame(...).write.mode("append").saveAsTable(...)`
(or, since the app runs outside a Spark session, via
`databricks-sql-connector` the same way `data_access.py` does its reads).
