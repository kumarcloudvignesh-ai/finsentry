"""
Synthetic spend data generator for "NorthBridge Industries" -- a fictional
mid-size industrial manufacturer used as the demo company for this project.

Generates 24 months of procurement/spend transactions with realistic,
INTENTIONAL patterns baked in so the analytics layer has real signal to find:

  1. IT & Software cost spike     - a SaaS renewal price hike in Q3 2025
  2. Maverick spend                - Professional Services & IT purchases made
                                      without a PO (a governance/compliance gap)
  3. Vendor concentration risk     - one Raw Materials vendor owns ~65% of the
                                      category (renegotiation / diversification target)
  4. Off-contract Travel spend     - bookings through non-preferred vendors at a
                                      cost premium (steerage opportunity)
  5. Vendor fragmentation in MRO   - many small overlapping vendors doing the
                                      same thing (consolidation opportunity)
  6. Budget overrun                - Manufacturing Operations trending over budget
                                      from Q2 2025 onward

Run:
    python generate_finance_data.py
Writes CSVs to ./raw/
"""

import os
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
OUT_DIR = os.path.join("/Workspace/Users/decidrix2@gmail.com/finsentry/data", "raw")
os.makedirs(OUT_DIR, exist_ok=True)

MONTHS = pd.date_range("2024-01-01", "2025-12-01", freq="MS")  # 24 months

# ---------------------------------------------------------------------------
# Dimension: Departments
# ---------------------------------------------------------------------------
departments = pd.DataFrame([
    {"department_id": "D01", "department_name": "Manufacturing Operations", "annual_budget": 9_200_000},
    {"department_id": "D02", "department_name": "Supply Chain",             "annual_budget": 4_600_000},
    {"department_id": "D03", "department_name": "IT",                       "annual_budget": 2_800_000},
    {"department_id": "D04", "department_name": "Sales & Marketing",        "annual_budget": 2_100_000},
    {"department_id": "D05", "department_name": "R&D",                      "annual_budget": 3_400_000},
    {"department_id": "D06", "department_name": "Finance",                  "annual_budget": 900_000},
    {"department_id": "D07", "department_name": "HR",                       "annual_budget": 700_000},
    {"department_id": "D08", "department_name": "Facilities",               "annual_budget": 1_900_000},
])

# ---------------------------------------------------------------------------
# Dimension: Categories
# ---------------------------------------------------------------------------
categories = pd.DataFrame([
    {"category_id": "C01", "category_name": "Raw Materials",          "category_group": "Direct Spend"},
    {"category_id": "C02", "category_name": "Logistics & Freight",    "category_group": "Direct Spend"},
    {"category_id": "C03", "category_name": "IT & Software",          "category_group": "Indirect Spend"},
    {"category_id": "C04", "category_name": "Professional Services",  "category_group": "Indirect Spend"},
    {"category_id": "C05", "category_name": "Travel & Entertainment", "category_group": "Indirect Spend"},
    {"category_id": "C06", "category_name": "MRO Supplies",           "category_group": "Indirect Spend"},
    {"category_id": "C07", "category_name": "Marketing",              "category_group": "Indirect Spend"},
    {"category_id": "C08", "category_name": "Facilities & Utilities", "category_group": "Indirect Spend"},
])

# ---------------------------------------------------------------------------
# Dimension: Vendors (mapped to categories, with intentional concentration
# and fragmentation patterns)
# ---------------------------------------------------------------------------
vendor_rows = []
vid = 1

def add_vendor(name, category_id, preferred, weight):
    global vid
    vendor_rows.append({
        "vendor_id": f"V{vid:03d}", "vendor_name": name, "category_id": category_id,
        "preferred_vendor": preferred, "spend_weight": weight,
    })
    vid += 1

# Raw Materials: one dominant vendor (concentration risk) + 3 smaller ones
add_vendor("Atlas Metals Supply", "C01", True, 0.65)
add_vendor("Continental Alloys", "C01", True, 0.15)
add_vendor("Ferrostone Materials", "C01", False, 0.12)
add_vendor("Ridgeline Raw Co", "C01", False, 0.08)

# Logistics & Freight
add_vendor("Vantage Freight Lines", "C02", True, 0.5)
add_vendor("Harborline Logistics", "C02", True, 0.3)
add_vendor("QuickHaul Transport", "C02", False, 0.2)

# IT & Software: includes the SaaS vendor with the Q3-2025 renewal spike, plus
# a long tail of small "shadow IT" subscriptions bought without a PO
add_vendor("CoreStack Cloud Platform", "C03", True, 0.35)
add_vendor("Nexus ERP Solutions", "C03", True, 0.20)
add_vendor("BrightPoint Analytics SaaS", "C03", False, 0.10)
add_vendor("PixelFlow Design Tools", "C03", False, 0.07)
add_vendor("DevSpark CI/CD", "C03", False, 0.07)
add_vendor("QuickSign eSignature", "C03", False, 0.06)
add_vendor("MetricEdge Dashboards", "C03", False, 0.06)
add_vendor("TinyTools Chrome Extensions Inc", "C03", False, 0.05)
add_vendor("FormBuddy Surveys", "C03", False, 0.04)

# Professional Services: consulting/staffing, several booked off-contract
add_vendor("Meridian Consulting Group", "C04", True, 0.40)
add_vendor("Apex Advisory Partners", "C04", True, 0.25)
add_vendor("Rapid Staffing Solutions", "C04", False, 0.20)
add_vendor("FreelanceHub Contractors", "C04", False, 0.15)

# Travel & Entertainment: one preferred agency, several off-contract bookings
add_vendor("Summit Corporate Travel", "C05", True, 0.55)
add_vendor("Skyline Direct Airlines", "C05", False, 0.20)
add_vendor("CityStay Hotels Direct", "C05", False, 0.15)
add_vendor("GoNow Rideshare", "C05", False, 0.10)

# MRO Supplies: highly fragmented, many small overlapping suppliers
for i, nm in enumerate([
    "IndustrialParts Direct", "FastenerWorld", "ToolShed Wholesale",
    "SafetyFirst Supply Co", "GripTech Hardware", "PlantSupply Now",
    "BoltAndBrace Co", "MRO Depot Express",
]):
    add_vendor(nm, "C06", i < 2, round(1 / 8, 3))

# Marketing
add_vendor("Beacon Creative Agency", "C07", True, 0.5)
add_vendor("AdSphere Digital", "C07", True, 0.3)
add_vendor("Freelance Design Collective", "C07", False, 0.2)

# Facilities & Utilities
add_vendor("MetroGrid Utilities", "C08", True, 0.45)
add_vendor("CleanSweep Facility Services", "C08", True, 0.30)
add_vendor("SecureGuard Property Services", "C08", False, 0.25)

vendors = pd.DataFrame(vendor_rows)

# ---------------------------------------------------------------------------
# Transactions
# ---------------------------------------------------------------------------
department_category_affinity = {
    "D01": {"C01": 0.55, "C02": 0.15, "C06": 0.20, "C08": 0.10},
    "D02": {"C02": 0.55, "C01": 0.20, "C06": 0.15, "C08": 0.10},
    "D03": {"C03": 0.85, "C04": 0.15},
    "D04": {"C07": 0.55, "C05": 0.30, "C04": 0.15},
    "D05": {"C04": 0.35, "C03": 0.30, "C01": 0.20, "C06": 0.15},
    "D06": {"C04": 0.60, "C03": 0.40},
    "D07": {"C04": 0.45, "C05": 0.25, "C03": 0.30},
    "D08": {"C08": 0.70, "C06": 0.30},
}

BASE_MONTHLY_AMOUNT = {  # total company spend per category per "normal" month, $
    "C01": 340_000, "C02": 150_000, "C03": 95_000, "C04": 110_000,
    "C05": 55_000, "C06": 60_000, "C07": 70_000, "C08": 80_000,
}

rows = []
txn_id = 100000

for m_idx, month in enumerate(MONTHS):
    q = (month.month - 1) // 3 + 1
    year = month.year
    is_q3_2025 = (year == 2025 and q == 3)
    is_h2_2025 = (year == 2025 and month.month >= 4)

    for cat in categories["category_id"]:
        base = BASE_MONTHLY_AMOUNT[cat]

        # seasonal + trend effects -------------------------------------------------
        multiplier = 1.0
        if cat == "C05":  # Travel: seasonal bump in Q2 (conferences) and Q4 (year-end)
            multiplier *= 1.35 if month.month in (4, 5, 6, 11, 12) else 0.9
        if cat == "C03" and is_q3_2025:  # IT SaaS renewal price hike
            multiplier *= 1.55
        if cat == "C03" and year == 2025 and month.month >= 10:  # hike persists post-renewal
            multiplier *= 1.35
        if cat == "C02":  # Logistics: gradual freight cost inflation
            multiplier *= 1 + 0.012 * m_idx
        if cat == "C01" and is_h2_2025:  # raw materials mild inflation
            multiplier *= 1 + 0.006 * m_idx

        month_total = base * multiplier * rng.normal(1.0, 0.05)

        cat_vendors = vendors[vendors.category_id == cat]
        weights = cat_vendors["spend_weight"].values
        weights = weights / weights.sum()

        n_txns = rng.integers(15, 45)
        txn_amounts = rng.dirichlet(np.ones(n_txns)) * month_total

        depts_for_cat = [d for d, aff in department_category_affinity.items() if cat in aff]
        dept_weights = [department_category_affinity[d][cat] for d in depts_for_cat]
        dept_weights = np.array(dept_weights) / sum(dept_weights)

        for amt in txn_amounts:
            vendor = cat_vendors.sample(1, weights=weights, random_state=int(rng.integers(1e9))).iloc[0]
            dept_id = rng.choice(depts_for_cat, p=dept_weights)

            # --- maverick spend injection (no PO) -------------------------------
            no_po_base_rate = 0.06
            if cat == "C04":
                no_po_base_rate = 0.28          # Professional Services: weak PO discipline
            if cat == "C03" and not vendor["preferred_vendor"]:
                no_po_base_rate = 0.55          # shadow-IT subscriptions rarely go through procurement
            has_po = rng.random() > no_po_base_rate

            # --- off-contract travel cost premium -------------------------------
            cost_premium = 1.0
            if cat == "C05" and not vendor["preferred_vendor"]:
                cost_premium = rng.uniform(1.15, 1.35)

            day = int(rng.integers(1, 28))
            txn_id += 1
            rows.append({
                "transaction_id": f"TXN{txn_id}",
                "date": month + pd.Timedelta(days=day),
                "department_id": dept_id,
                "vendor_id": vendor["vendor_id"],
                "category_id": cat,
                "amount": round(float(amt) * cost_premium, 2),
                "po_number": None if not has_po else f"PO{rng.integers(100000, 999999)}",
                "payment_terms_days": int(rng.choice([15, 30, 45, 60])),
            })

transactions = pd.DataFrame(rows)

# ---------------------------------------------------------------------------
# Monthly department budgets -- calibrated to each department's actual 2024
# (pre-inflation) run-rate plus a 5% buffer, then held flat. This is what
# lets the Q2-2025-onward Raw Materials / IT cost inflation show up as a
# real, explainable budget overrun rather than an arbitrary top-down number.
# ---------------------------------------------------------------------------
baseline_2024 = (
    transactions[transactions["date"] < "2025-01-01"]
    .groupby("department_id")["amount"].sum()
    / 12
)

budget_rows = []
for _, d in departments.iterrows():
    monthly_base = baseline_2024.get(d["department_id"], 50_000) * 1.05
    for month in MONTHS:
        seasonal = 1.05 if month.month in (11, 12) else 1.0
        budget_rows.append({
            "department_id": d["department_id"],
            "month": month,
            "budget_amount": round(monthly_base * seasonal, 2),
        })
budgets = pd.DataFrame(budget_rows)

# ---------------------------------------------------------------------------
# Write raw files
# ---------------------------------------------------------------------------
departments.to_csv(f"{OUT_DIR}/departments.csv", index=False)
categories.to_csv(f"{OUT_DIR}/categories.csv", index=False)
vendors.drop(columns=["spend_weight"]).to_csv(f"{OUT_DIR}/vendors.csv", index=False)
transactions.to_csv(f"{OUT_DIR}/transactions.csv", index=False)
budgets.to_csv(f"{OUT_DIR}/budgets.csv", index=False)

print(f"departments:   {len(departments)}")
print(f"categories:    {len(categories)}")
print(f"vendors:       {len(vendors)}")
print(f"transactions:  {len(transactions)}  (${transactions['amount'].sum():,.0f} total)")
print(f"budgets:       {len(budgets)}")
print(f"\nWrote CSVs to {OUT_DIR}/")
