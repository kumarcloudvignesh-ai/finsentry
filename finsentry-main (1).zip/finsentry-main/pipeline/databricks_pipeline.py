# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# =============================================================================
# FinSentry Spend Intelligence -- Lakehouse Pipeline
# =============================================================================
# Run this as a Databricks notebook (or import it into a Databricks Job /
# Workflow -- see docs/README_DEPLOY.md). It assumes:
#   - `spark` and `dbutils` are the notebook-injected globals (no imports needed)
#   - The 5 raw CSVs from data/generate_finance_data.py have been uploaded to
#     a Unity Catalog Volume (path set below)
#   - You have CREATE TABLE privileges on the target catalog/schema
#
# What it builds (all as managed Delta tables in Unity Catalog):
#   Bronze  -> raw CSVs loaded as-is
#   Silver  -> typed, cleaned, joined to dimensions
#   Gold    -> the 5 tables the Streamlit app + agents read from:
#       gold_spend_by_category_month
#       gold_spend_by_vendor
#       gold_budget_variance
#       gold_maverick_spend
#       gold_savings_opportunities
#   Vector Search index over the finance policy / contract / narrative docs
# =============================================================================

# COMMAND ----------

dbutils.widgets.text("catalog", "finsentry", "Unity Catalog catalog name")
dbutils.widgets.text("schema", "spend_analytics", "Schema name")
dbutils.widgets.text("volume_path", "/Volumes/finsentry/spend_analytics/raw_files", "Volume path with uploaded CSVs/docs")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA = dbutils.widgets.get("schema")
VOLUME_PATH = dbutils.widgets.get("volume_path")

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

# COMMAND ----------

# ---------------------------------------------------------------------------
# BRONZE -- raw CSVs, loaded as-is
# ---------------------------------------------------------------------------
from pyspark.sql import functions as F

def load_bronze(name, filename):
    df = (spark.read.format("csv")
          .option("header", True)
          .option("inferSchema", True)
          .load(f"{VOLUME_PATH}/{filename}"))
    df.write.mode("overwrite").saveAsTable(f"bronze_{name}")
    return df

bronze_departments = load_bronze("departments", "departments.csv")
bronze_categories = load_bronze("categories", "categories.csv")
bronze_vendors = load_bronze("vendors", "vendors.csv")
bronze_transactions = load_bronze("transactions", "transactions.csv")
bronze_budgets = load_bronze("budgets", "budgets.csv")

# COMMAND ----------

# DBTITLE 1,Cell 5
# ---------------------------------------------------------------------------
# SILVER -- typed + joined
# ---------------------------------------------------------------------------
# Add aliases to avoid column name conflicts during joins
vendors = spark.table("bronze_vendors").alias("v")
categories = spark.table("bronze_categories").alias("c")
departments = spark.table("bronze_departments").alias("d")

silver_transactions = (
    spark.table("bronze_transactions").alias("t")
    .withColumn("date_typed", F.to_date("date"))
    .withColumn("month", F.trunc("date_typed", "month"))
    .withColumn("has_po", F.col("po_number").isNotNull())
    .join(vendors, F.col("t.vendor_id") == F.col("v.vendor_id"), "left")
    .join(categories, F.col("t.category_id") == F.col("c.category_id"), "left")
    .join(departments, F.col("t.department_id") == F.col("d.department_id"), "left")
    .select(
        F.col("t.transaction_id"),
        F.col("date_typed").alias("date"),
        F.col("month"),
        F.col("t.amount"),
        F.col("t.po_number"),
        F.col("has_po"),
        F.col("t.vendor_id"),
        F.col("v.vendor_name"),
        F.col("v.preferred_vendor"),
        F.col("t.category_id"),
        F.col("c.category_name"),
        F.col("c.category_group"),
        F.col("t.department_id"),
        F.col("d.department_name")
    )
)
silver_transactions.write.mode("overwrite").saveAsTable("silver_transactions_enriched")

silver_budgets = (
    spark.table("bronze_budgets").alias("b")
    .withColumn("month", F.to_date("month"))
    .join(departments, F.col("b.department_id") == F.col("d.department_id"), "left")
    .select(
        F.col("b.department_id"),
        F.col("d.department_name"),
        F.col("month"),
        F.col("b.budget_amount")
    )
)
silver_budgets.write.mode("overwrite").saveAsTable("silver_budgets_enriched")

# COMMAND ----------

# ---------------------------------------------------------------------------
# GOLD 1: spend by category by month
# ---------------------------------------------------------------------------
gold_spend_by_category_month = (
    spark.table("silver_transactions_enriched")
    .groupBy("month", "category_id", "category_name", "category_group")
    .agg(F.sum("amount").alias("total_spend"), F.count("*").alias("transaction_count"))
    .orderBy("month", "category_id")
)
gold_spend_by_category_month.write.mode("overwrite").saveAsTable("gold_spend_by_category_month")

# COMMAND ----------

# ---------------------------------------------------------------------------
# GOLD 2: spend by vendor, with within-category concentration %
# ---------------------------------------------------------------------------
from pyspark.sql.window import Window

vendor_spend = (
    spark.table("silver_transactions_enriched")
    .groupBy("category_id", "category_name", "vendor_id", "vendor_name", "preferred_vendor")
    .agg(F.sum("amount").alias("vendor_spend"), F.count("*").alias("transaction_count"))
)
cat_window = Window.partitionBy("category_id")
gold_spend_by_vendor = (
    vendor_spend
    .withColumn("category_total", F.sum("vendor_spend").over(cat_window))
    .withColumn("pct_of_category", F.round(F.col("vendor_spend") / F.col("category_total") * 100, 1))
    .orderBy("category_id", F.desc("vendor_spend"))
)
gold_spend_by_vendor.write.mode("overwrite").saveAsTable("gold_spend_by_vendor")

# COMMAND ----------

# ---------------------------------------------------------------------------
# GOLD 3: budget variance by department by month
# ---------------------------------------------------------------------------
actual_by_dept_month = (
    spark.table("silver_transactions_enriched")
    .groupBy("month", "department_id", "department_name")
    .agg(F.sum("amount").alias("actual_spend"))
)
gold_budget_variance = (
    actual_by_dept_month
    .join(spark.table("silver_budgets_enriched"), ["month", "department_id", "department_name"])
    .withColumn("variance_amount", F.col("actual_spend") - F.col("budget_amount"))
    .withColumn("variance_pct", F.round(F.col("variance_amount") / F.col("budget_amount") * 100, 1))
    .orderBy("month", "department_id")
)
gold_budget_variance.write.mode("overwrite").saveAsTable("gold_budget_variance")

# COMMAND ----------

# ---------------------------------------------------------------------------
# GOLD 4: maverick spend (no PO) by category / department
# ---------------------------------------------------------------------------
gold_maverick_spend = (
    spark.table("silver_transactions_enriched")
    .groupBy("category_id", "category_name", "department_id", "department_name")
    .agg(
        F.sum(F.when(~F.col("has_po"), F.col("amount")).otherwise(0)).alias("no_po_spend"),
        F.sum("amount").alias("total_spend"),
    )
    .withColumn("pct_no_po", F.round(F.col("no_po_spend") / F.col("total_spend") * 100, 1))
    .filter(F.col("total_spend") > 0)
    .orderBy(F.desc("pct_no_po"))
)
gold_maverick_spend.write.mode("overwrite").saveAsTable("gold_maverick_spend")

# COMMAND ----------

# ---------------------------------------------------------------------------
# GOLD 5: savings opportunities -- rule-based candidates the Analytics Agent
# and the Streamlit dashboard both surface. Each row is a distinct, explainable
# lever with a rough estimated annualized savings range.
# ---------------------------------------------------------------------------
opportunities = []

# a) Vendor concentration risk (>50% of category owned by one vendor)
concentration = spark.sql("""
    SELECT category_name, vendor_name, pct_of_category, vendor_spend
    FROM gold_spend_by_vendor
    WHERE pct_of_category > 50
""").collect()
for r in concentration:
    opportunities.append((
        "Vendor concentration risk", r["category_name"],
        f"{r['vendor_name']} holds {r['pct_of_category']}% of {r['category_name']} spend -- "
        f"limited negotiating leverage and supply continuity risk.",
        round(r["vendor_spend"] * 0.03, 0),  # illustrative: 3% renegotiation upside
    ))

# b) Off-contract / non-preferred vendor premium (Travel & similar) -- flag
#    categories where non-preferred vendors carry a real share (>30%) of spend
non_preferred = spark.sql("""
    SELECT category_name,
           SUM(CASE WHEN NOT preferred_vendor THEN vendor_spend ELSE 0 END) AS non_preferred_spend,
           SUM(vendor_spend) AS category_total
    FROM gold_spend_by_vendor
    GROUP BY category_name
    HAVING SUM(CASE WHEN NOT preferred_vendor THEN vendor_spend ELSE 0 END) / SUM(vendor_spend) > 0.30
""").collect()
for r in non_preferred:
    pct = r["non_preferred_spend"] / r["category_total"] * 100
    opportunities.append((
        "Off-contract vendor spend", r["category_name"],
        f"${r['non_preferred_spend']:,.0f} ({pct:.0f}%) of {r['category_name']} spend went to "
        f"non-preferred vendors; consolidating to preferred vendors typically saves 15-35%.",
        round(r["non_preferred_spend"] * 0.20, 0),
    ))

# c) Maverick (no-PO) spend above policy threshold (15%)
maverick = spark.sql("""
    SELECT category_name, SUM(no_po_spend) AS no_po_total, SUM(total_spend) AS total
    FROM gold_maverick_spend
    GROUP BY category_name
    HAVING SUM(no_po_spend) / SUM(total_spend) > 0.15
""").collect()
for r in maverick:
    opportunities.append((
        "PO compliance gap", r["category_name"],
        f"${r['no_po_total']:,.0f} ({r['no_po_total']/r['total']*100:.0f}%) of "
        f"{r['category_name']} spend bypassed the PO process, forgoing negotiated pricing.",
        round(r["no_po_total"] * 0.10, 0),
    ))

# d) Vendor fragmentation (many small vendors in one category -> consolidation)
fragmentation = spark.sql("""
    SELECT category_name, COUNT(DISTINCT vendor_name) AS vendor_count, SUM(vendor_spend) AS total
    FROM gold_spend_by_vendor
    GROUP BY category_name
    HAVING COUNT(DISTINCT vendor_name) >= 6
""").collect()
for r in fragmentation:
    opportunities.append((
        "Vendor fragmentation", r["category_name"],
        f"{r['vendor_count']} active vendors share {r['category_name']} spend with overlapping "
        f"catalogs; consolidating to 1-2 national accounts typically captures 5-12% volume pricing.",
        round(r["total"] * 0.08, 0),
    ))

gold_savings_opportunities = spark.createDataFrame(
    opportunities,
    schema=["opportunity_type", "category_name", "description", "estimated_annual_savings"],
)
gold_savings_opportunities.write.mode("overwrite").saveAsTable("gold_savings_opportunities")

# COMMAND ----------

# ---------------------------------------------------------------------------
# UNSTRUCTURED DOCS -> table for Vector Search (policy / contracts / narrative)
# ---------------------------------------------------------------------------
doc_files = [
    "policy_procurement.txt",
    "vendor_contracts_summary.txt",
    "quarterly_spend_narrative_2025q3.txt",
]

doc_rows = []
for i, fname in enumerate(doc_files):
    text = dbutils.fs.head(f"{VOLUME_PATH}/{fname}", 100000)
    # simple paragraph-level chunking keeps each vector-search hit focused
    for j, chunk in enumerate([c.strip() for c in text.split("\n\n") if c.strip()]):
        doc_rows.append((f"doc{i}_chunk{j}", fname, chunk))

docs_df = spark.createDataFrame(doc_rows, schema=["chunk_id", "source_file", "text"])
docs_df.write.mode("overwrite").option("delta.enableChangeDataFeed", "true").saveAsTable("gold_finance_documents")

# COMMAND ----------

# DBTITLE 1,Install Vector Search package
# MAGIC %pip install databricks-vectorsearch
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Cell 11
# ---------------------------------------------------------------------------
# VECTOR SEARCH -- create endpoint + Delta Sync index over gold_finance_documents
# ---------------------------------------------------------------------------
try:
    from databricks.vector_search.client import VectorSearchClient
except ImportError:
    print("Installing databricks-vectorsearch...")
    import subprocess
    import sys
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "databricks-vectorsearch"])
    from databricks.vector_search.client import VectorSearchClient

VS_ENDPOINT = "finsentry_vs_endpoint"
VS_INDEX = f"{CATALOG}.{SCHEMA}.finance_docs_index"

vsc = VectorSearchClient()

existing_endpoints = [e["name"] for e in vsc.list_endpoints().get("endpoints", [])]
if VS_ENDPOINT not in existing_endpoints:
    vsc.create_endpoint(name=VS_ENDPOINT, endpoint_type="STANDARD")

try:
    vsc.create_delta_sync_index(
        endpoint_name=VS_ENDPOINT,
        source_table_name=f"{CATALOG}.{SCHEMA}.gold_finance_documents",
        index_name=VS_INDEX,
        pipeline_type="TRIGGERED",
        primary_key="chunk_id",
        embedding_source_column="text",
        embedding_model_endpoint_name="databricks-qwen3-embedding-0-6b",  # Databricks-hosted embedding model
    )
except Exception as e:
    print(f"Index may already exist, attempting sync instead: {e}")
    vsc.get_index(index_name=VS_INDEX).sync()

# COMMAND ----------

print("Pipeline complete. Gold tables:")
for t in ["gold_spend_by_category_month", "gold_spend_by_vendor", "gold_budget_variance",
          "gold_maverick_spend", "gold_savings_opportunities", "gold_finance_documents"]:
    cnt = spark.table(t).count()
    print(f"  {CATALOG}.{SCHEMA}.{t}: {cnt} rows")
print(f"Vector Search index ready: {VS_INDEX}")