"""
Local, dependency-light mirror of pipeline/databricks_pipeline.py.

Produces the SAME five Gold tables (same column names) as pandas parquet
files under data/gold/, using the same business logic, so you can develop
and sanity-check the Analytics Agent and Streamlit dashboard on your laptop
before ever touching a Databricks workspace.

Run:
    python local_pipeline_demo.py
"""

import os
import pandas as pd

BASE = "/Workspace/Users/decidrix@gmail.com/finsentry/"
RAW = os.path.join(BASE, "data", "raw")
DOCS = os.path.join(BASE, "docs")
GOLD = os.path.join(BASE, "data", "gold")
os.makedirs(GOLD, exist_ok=True)

departments = pd.read_csv(f"{RAW}/departments.csv")
categories = pd.read_csv(f"{RAW}/categories.csv")
vendors = pd.read_csv(f"{RAW}/vendors.csv")
transactions = pd.read_csv(f"{RAW}/transactions.csv", parse_dates=["date"])
budgets = pd.read_csv(f"{RAW}/budgets.csv", parse_dates=["month"])

# ---------------------------------------------------------------------------
# Silver: enrich transactions
# ---------------------------------------------------------------------------
transactions["month"] = transactions["date"].values.astype("datetime64[M]")
transactions["has_po"] = transactions["po_number"].notna()
txn = (transactions
       .merge(vendors.drop(columns=["category_id"]), on="vendor_id")
       .merge(categories, on="category_id")
       .merge(departments, on="department_id"))

# ---------------------------------------------------------------------------
# Gold 1: spend by category by month
# ---------------------------------------------------------------------------
gold_spend_by_category_month = (
    txn.groupby(["month", "category_id", "category_name", "category_group"])
    .agg(total_spend=("amount", "sum"), transaction_count=("amount", "size"))
    .reset_index()
    .sort_values(["month", "category_id"])
)
gold_spend_by_category_month.to_parquet(f"{GOLD}/gold_spend_by_category_month.parquet", index=False)

# ---------------------------------------------------------------------------
# Gold 2: spend by vendor with within-category concentration %
# ---------------------------------------------------------------------------
vendor_spend = (
    txn.groupby(["category_id", "category_name", "vendor_id", "vendor_name", "preferred_vendor"])
    .agg(vendor_spend=("amount", "sum"), transaction_count=("amount", "size"))
    .reset_index()
)
cat_totals = vendor_spend.groupby("category_id")["vendor_spend"].transform("sum")
vendor_spend["category_total"] = cat_totals
vendor_spend["pct_of_category"] = (vendor_spend["vendor_spend"] / cat_totals * 100).round(1)
gold_spend_by_vendor = vendor_spend.sort_values(["category_id", "vendor_spend"], ascending=[True, False])
gold_spend_by_vendor.to_parquet(f"{GOLD}/gold_spend_by_vendor.parquet", index=False)

# ---------------------------------------------------------------------------
# Gold 3: budget variance by department by month
# ---------------------------------------------------------------------------
actual_by_dept_month = (
    txn.groupby(["month", "department_id", "department_name"])
    .agg(actual_spend=("amount", "sum"))
    .reset_index()
)
budgets_enriched = budgets.merge(departments, on="department_id")
gold_budget_variance = actual_by_dept_month.merge(
    budgets_enriched, on=["month", "department_id", "department_name"]
)
gold_budget_variance["variance_amount"] = gold_budget_variance["actual_spend"] - gold_budget_variance["budget_amount"]
gold_budget_variance["variance_pct"] = (
    gold_budget_variance["variance_amount"] / gold_budget_variance["budget_amount"] * 100
).round(1)
gold_budget_variance = gold_budget_variance.sort_values(["month", "department_id"])
gold_budget_variance.to_parquet(f"{GOLD}/gold_budget_variance.parquet", index=False)

# ---------------------------------------------------------------------------
# Gold 4: maverick spend (no PO) by category / department
# ---------------------------------------------------------------------------
txn["no_po_amount"] = txn["amount"].where(~txn["has_po"], 0.0)
maverick = (
    txn.groupby(["category_id", "category_name", "department_id", "department_name"])
    .agg(no_po_spend=("no_po_amount", "sum"), total_spend=("amount", "sum"))
    .reset_index()
)
maverick = maverick[maverick["total_spend"] > 0]
maverick["pct_no_po"] = (maverick["no_po_spend"] / maverick["total_spend"] * 100).round(1)
gold_maverick_spend = maverick.sort_values("pct_no_po", ascending=False)
gold_maverick_spend.to_parquet(f"{GOLD}/gold_maverick_spend.parquet", index=False)

# ---------------------------------------------------------------------------
# Gold 5: savings opportunities (same rule set as the Databricks pipeline)
# ---------------------------------------------------------------------------
opportunities = []

concentration = gold_spend_by_vendor[gold_spend_by_vendor["pct_of_category"] > 50]
for _, r in concentration.iterrows():
    opportunities.append({
        "opportunity_type": "Vendor concentration risk",
        "category_name": r["category_name"],
        "description": (
            f"{r['vendor_name']} holds {r['pct_of_category']}% of {r['category_name']} spend -- "
            f"limited negotiating leverage and supply continuity risk."
        ),
        "estimated_annual_savings": round(r["vendor_spend"] * 0.03, 0),
    })

cat_total = gold_spend_by_vendor.groupby("category_name")["vendor_spend"].sum()
non_preferred = (
    gold_spend_by_vendor[~gold_spend_by_vendor["preferred_vendor"]]
    .groupby("category_name")["vendor_spend"].sum().reset_index()
)
non_preferred["category_total"] = non_preferred["category_name"].map(cat_total)
non_preferred["pct_non_preferred"] = non_preferred["vendor_spend"] / non_preferred["category_total"] * 100
non_preferred = non_preferred[non_preferred["pct_non_preferred"] > 30]
for _, r in non_preferred.iterrows():
    opportunities.append({
        "opportunity_type": "Off-contract vendor spend",
        "category_name": r["category_name"],
        "description": (
            f"${r['vendor_spend']:,.0f} ({r['pct_non_preferred']:.0f}%) of {r['category_name']} spend "
            f"went to non-preferred vendors; consolidating to preferred vendors typically saves 15-35%."
        ),
        "estimated_annual_savings": round(r["vendor_spend"] * 0.20, 0),
    })

mav_agg = gold_maverick_spend.groupby("category_name").agg(
    no_po_total=("no_po_spend", "sum"), total=("total_spend", "sum")
).reset_index()
mav_agg = mav_agg[mav_agg["no_po_total"] / mav_agg["total"] > 0.15]
for _, r in mav_agg.iterrows():
    pct = r["no_po_total"] / r["total"] * 100
    opportunities.append({
        "opportunity_type": "PO compliance gap",
        "category_name": r["category_name"],
        "description": (
            f"${r['no_po_total']:,.0f} ({pct:.0f}%) of {r['category_name']} spend bypassed "
            f"the PO process, forgoing negotiated pricing."
        ),
        "estimated_annual_savings": round(r["no_po_total"] * 0.10, 0),
    })

frag = gold_spend_by_vendor.groupby("category_name").agg(
    vendor_count=("vendor_name", "nunique"), total=("vendor_spend", "sum")
).reset_index()
frag = frag[frag["vendor_count"] >= 6]
for _, r in frag.iterrows():
    opportunities.append({
        "opportunity_type": "Vendor fragmentation",
        "category_name": r["category_name"],
        "description": (
            f"{r['vendor_count']} active vendors share {r['category_name']} spend with overlapping "
            f"catalogs; consolidating to 1-2 national accounts typically captures 5-12% volume pricing."
        ),
        "estimated_annual_savings": round(r["total"] * 0.08, 0),
    })

gold_savings_opportunities = pd.DataFrame(opportunities)
gold_savings_opportunities.to_parquet(f"{GOLD}/gold_savings_opportunities.parquet", index=False)

# ---------------------------------------------------------------------------
# Documents table for the local RAG fallback (paragraph-chunked)
# ---------------------------------------------------------------------------
doc_rows = []
for fname in ["policy_procurement.txt", "vendor_contracts_summary.txt", "quarterly_spend_narrative_2025q3.txt"]:
    with open(f"{DOCS}/{fname}") as f:
        text = f.read()
    for j, chunk in enumerate([c.strip() for c in text.split("\n\n") if c.strip()]):
        doc_rows.append({"chunk_id": f"{fname}_chunk{j}", "source_file": fname, "text": chunk})
gold_finance_documents = pd.DataFrame(doc_rows)
gold_finance_documents.to_parquet(f"{GOLD}/gold_finance_documents.parquet", index=False)

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print("Local Gold layer built at", GOLD)
print(f"  gold_spend_by_category_month : {len(gold_spend_by_category_month)} rows")
print(f"  gold_spend_by_vendor         : {len(gold_spend_by_vendor)} rows")
print(f"  gold_budget_variance         : {len(gold_budget_variance)} rows")
print(f"  gold_maverick_spend          : {len(gold_maverick_spend)} rows")
print(f"  gold_savings_opportunities   : {len(gold_savings_opportunities)} rows")
print(f"  gold_finance_documents       : {len(gold_finance_documents)} rows")

print("\nTop 5 savings opportunities by estimated annual savings:")
print(
    gold_savings_opportunities.sort_values("estimated_annual_savings", ascending=False)
    .head(5)[["opportunity_type", "category_name", "estimated_annual_savings"]]
    .to_string(index=False)
)
