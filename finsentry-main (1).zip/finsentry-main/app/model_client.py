"""
Production LLM client for FinSentry.

Backends (tried in order):
  1. Databricks Foundation Model APIs -- auto-discovered via the Databricks
     SDK runtime or overridden via DATABRICKS_HOST / DATABRICKS_TOKEN env
     vars. Calls a pay-per-token endpoint via the OpenAI-compatible client.
  2. Direct Anthropic API -- for local development without a Databricks
     workspace. Set ANTHROPIC_API_KEY to activate.
  3. Deterministic offline fallback -- always available, no network calls.

Design notes:
  - All credential discovery is lazy (nothing runs at import time).
  - Databricks OAuth tokens are refreshed on every call via the SDK.
  - Public API (generate, route_intent, active_backend) is stable so
    agents.py needs no changes.
"""

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
@dataclass
class LLMConfig:
    """Configurable parameters for LLM calls."""
    max_tokens: int = 400
    temperature: float = 0.0
    databricks_model: str = field(
        default_factory=lambda: os.environ.get(
            "DATABRICKS_SERVING_MODEL", "databricks-meta-llama-3-3-70b-instruct"
        )
    )
    anthropic_model: str = "claude-sonnet-4-20250514"


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = (
    "You are FinSentry, a finance operations assistant for NorthBridge "
    "Industries. Answer the user's question using ONLY the structured spend "
    "analysis and the retrieved policy/contract excerpts provided in the "
    "prompt. Be concise, cite concrete numbers from the analysis, and end "
    "with one clear recommended action when the data supports one. Never "
    "invent figures that aren't in the context."
)

ROUTING_SYSTEM_PROMPT = (
    "You are an intent router for a spend analytics assistant. "
    "Given a user question, identify which spend category and/or department "
    "it relates to. Return ONLY a JSON object with keys 'category' and "
    "'department'. Use empty string for either key if the question doesn't "
    "mention one. Do not include any text outside the JSON object."
)


# ---------------------------------------------------------------------------
# Internal client singleton
# ---------------------------------------------------------------------------
class _LLMClient:
    """Manages backend selection, credential discovery, and LLM calls.

    All credential discovery is lazy -- nothing runs until the first call.
    """

    def __init__(self, config: Optional[LLMConfig] = None):
        self._config = config or LLMConfig()
        self._workspace_client = None
        # Observability: stores metadata about the most recent LLM call
        self.last_call_info = {
            "backend": "none",
            "model": "",
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "duration_ms": 0.0,
        }

    # -- Credential discovery (lazy) --

    def _get_workspace_client(self):
        """Lazily create and cache a Databricks WorkspaceClient."""
        if self._workspace_client is None:
            from databricks.sdk import WorkspaceClient
            self._workspace_client = WorkspaceClient()
        return self._workspace_client

    def _databricks_host(self) -> Optional[str]:
        """Get the Databricks host from env var or SDK runtime."""
        host = os.environ.get("DATABRICKS_HOST")
        if host:
            return host.replace("https://", "").replace("http://", "")
        try:
            w = self._get_workspace_client()
            return w.config.host.replace("https://", "").replace("http://", "")
        except Exception:
            logger.debug("Could not discover Databricks host", exc_info=True)
            return None

    def _databricks_token(self) -> Optional[str]:
        """Get a fresh Databricks token (refreshed on each call)."""
        token = os.environ.get("DATABRICKS_TOKEN")
        if token:
            return token
        try:
            w = self._get_workspace_client()
            return w.config.authenticate()["Authorization"].replace("Bearer ", "")
        except Exception:
            logger.debug("Could not retrieve Databricks token", exc_info=True)
            return None

    def _has_databricks(self) -> bool:
        return self._databricks_host() is not None and self._databricks_token() is not None

    @staticmethod
    def _has_anthropic() -> bool:
        return bool(os.environ.get("ANTHROPIC_API_KEY"))

    @staticmethod
    def _call_with_retry(fn, max_attempts: int = 3, base_delay: float = 1.0):
        """Call fn with exponential backoff retry on transient failures."""
        last_exc = None
        for attempt in range(max_attempts):
            try:
                return fn()
            except Exception as e:
                last_exc = e
                if attempt < max_attempts - 1:
                    delay = base_delay * (2 ** attempt)
                    logger.warning("LLM call attempt %d/%d failed: %s (retrying in %.1fs)",
                                   attempt + 1, max_attempts, e, delay)
                    time.sleep(delay)
        raise last_exc


    # -- LLM calls --

    def _call_databricks(self, prompt: str, system: str) -> str:
        from openai import OpenAI

        host = self._databricks_host()
        token = self._databricks_token()
        client = OpenAI(
            api_key=token,
            base_url=f"https://{host}/serving-endpoints",
        )

        def _do_call():
            return client.chat.completions.create(
                model=self._config.databricks_model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=self._config.max_tokens,
                temperature=self._config.temperature,
            )

        t0 = time.time()
        resp = self._call_with_retry(_do_call)
        elapsed_ms = (time.time() - t0) * 1000
        prompt_t = resp.usage.prompt_tokens if resp.usage else 0
        completion_t = resp.usage.completion_tokens if resp.usage else 0
        total_t = resp.usage.total_tokens if resp.usage else 0
        if resp.usage:
            logger.info("Databricks token usage: prompt=%d completion=%d total=%d",
                        prompt_t, completion_t, total_t)
        self.last_call_info = {
            "backend": "databricks",
            "model": self._config.databricks_model,
            "prompt_tokens": prompt_t,
            "completion_tokens": completion_t,
            "total_tokens": total_t,
            "duration_ms": round(elapsed_ms, 1),
        }
        return resp.choices[0].message.content

    def _call_anthropic(self, prompt: str, system: str) -> str:
        import anthropic

        client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

        def _do_call():
            return client.messages.create(
                model=self._config.anthropic_model,
                max_tokens=self._config.max_tokens,
                system=system,
                messages=[{"role": "user", "content": prompt}],
            )

        t0 = time.time()
        resp = self._call_with_retry(_do_call)
        elapsed_ms = (time.time() - t0) * 1000
        prompt_t = resp.usage.input_tokens if resp.usage else 0
        completion_t = resp.usage.output_tokens if resp.usage else 0
        total_t = prompt_t + completion_t
        if resp.usage:
            logger.info("Anthropic token usage: input=%d output=%d",
                        prompt_t, completion_t)
        self.last_call_info = {
            "backend": "anthropic",
            "model": self._config.anthropic_model,
            "prompt_tokens": prompt_t,
            "completion_tokens": completion_t,
            "total_tokens": total_t,
            "duration_ms": round(elapsed_ms, 1),
        }
        return "".join(b.text for b in resp.content if hasattr(b, "text"))

    @staticmethod
    def _call_offline(prompt: str) -> str:
        """Deterministic, template-based fallback -- no external calls."""
        return (
            "[Offline mode -- set DATABRICKS_HOST/DATABRICKS_TOKEN or "
            "ANTHROPIC_API_KEY for a generated answer]\n\n" + prompt
        )

    def _set_offline_call_info(self):
        self.last_call_info = {
            "backend": "offline",
            "model": "template",
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "duration_ms": 0.0,
        }

    # -- Public methods --

    def generate(self, prompt: str, system: str = SYSTEM_PROMPT) -> str:
        """Generate a natural-language answer using the best available backend."""
        if self._has_databricks():
            try:
                return self._call_databricks(prompt, system)
            except Exception as e:
                logger.warning("Databricks LLM call failed: %s", e)
                self._set_offline_call_info()
                return f"[Databricks Model Serving call failed: {e}]\n\n" + self._call_offline(prompt)
        if self._has_anthropic():
            try:
                return self._call_anthropic(prompt, system)
            except Exception as e:
                logger.warning("Anthropic LLM call failed: %s", e)
                self._set_offline_call_info()
                return f"[Anthropic API call failed: {e}]\n\n" + self._call_offline(prompt)
        self._set_offline_call_info()
        return self._call_offline(prompt)

    def route_intent(self, question: str, categories: list, departments: list) -> dict:
        """Classify a question into a spend category and/or department via LLM.

        Returns a dict with 'category' and 'department' keys (empty strings
        if the question doesn't mention one). Falls back to empty strings on
        any error so the caller can fall back to keyword matching.
        """
        prompt = (
            f"Available categories: {', '.join(categories)}\n"
            f"Available departments: {', '.join(departments)}\n\n"
            f"Question: {question}\n\n"
            f'Respond with ONLY a JSON object: {{"category": "...", "department": "..."}}'
        )
        empty = {"category": "", "department": ""}
        if self._has_databricks():
            try:
                return self._parse_routing_response(
                    self._call_databricks(prompt, ROUTING_SYSTEM_PROMPT)
                )
            except Exception:
                logger.warning("Databricks routing call failed", exc_info=True)
                return empty
        if self._has_anthropic():
            try:
                return self._parse_routing_response(
                    self._call_anthropic(prompt, ROUTING_SYSTEM_PROMPT)
                )
            except Exception:
                logger.warning("Anthropic routing call failed", exc_info=True)
                return empty
        return empty

    @staticmethod
    def _parse_routing_response(text: str) -> dict:
        """Extract JSON from LLM response, stripping markdown fences."""
        cleaned = re.sub(r"```(?:json)?\s*", "", text).strip()
        try:
            result = json.loads(cleaned)
            return {
                "category": str(result.get("category", "")),
                "department": str(result.get("department", "")),
            }
        except (json.JSONDecodeError, AttributeError):
            return {"category": "", "department": ""}

    def active_backend(self) -> str:
        """Return a human-readable description of the active LLM backend."""
        if self._has_databricks():
            return f"Databricks Model Serving ({self._config.databricks_model})"
        if self._has_anthropic():
            return f"Anthropic API ({self._config.anthropic_model})"
        return "offline template (no LLM configured)"


# ---------------------------------------------------------------------------
# Singleton instance and public API (backward-compatible with agents.py)
# ---------------------------------------------------------------------------
_client = _LLMClient()


def configure(config: LLMConfig) -> None:
    """Override the default LLM configuration at runtime."""
    global _client
    _client = _LLMClient(config)


def generate(prompt: str) -> str:
    """Generate a natural-language answer using the best available LLM backend."""
    return _client.generate(prompt)


def route_intent(question: str, categories: list, departments: list) -> dict:
    """Classify a question into a spend category and/or department via LLM."""
    return _client.route_intent(question, categories, departments)


def active_backend() -> str:
    """Return a human-readable description of the active LLM backend."""
    return _client.active_backend()


def get_last_call_info() -> dict:
    """Return metadata about the most recent LLM call (tokens, duration, etc.)."""
    return _client.last_call_info
