"""
Unit tests for the FinSentry application.

Tests cover:
- check_permission role gate
- Orchestrator keyword fallback routing
- data_access ALLOWED_TABLES whitelist validation (SQL injection)
- model_client routing response JSON parsing
- analytics_agent formatting with maverick data
- Trace observability class
"""
import datetime
import os
import sys

import pytest

# Ensure the app directory is on the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class TestCheckPermission:
    """Test the Unity Catalog-style role gate."""

    def test_exec_can_access_all_categories(self):
        import agents
        assert agents.check_permission("exec", "Raw Materials") is True
        assert agents.check_permission("exec", "IT & Software") is True
        assert agents.check_permission("exec", "Marketing") is True

    def test_analyst_can_access_allowed_categories(self):
        import agents
        assert agents.check_permission("analyst", "Raw Materials") is True
        assert agents.check_permission("analyst", "IT & Software") is True

    def test_analyst_empty_category_denied(self):
        import agents
        assert agents.check_permission("analyst", "") is False

    def test_unknown_role_denied(self):
        import agents
        assert agents.check_permission("viewer", "Raw Materials") is False

    def test_analyst_all_categories_accessible(self):
        import agents
        for cat in agents.CATEGORY_NAMES:
            assert agents.check_permission("analyst", cat) is True


class TestOrchestratorKeywordFallback:
    """Test orchestrator routing with keyword fallback (no LLM configured)."""

    def _make_state(self, question, role="analyst"):
        import agents
        return {
            "session_id": "test-123",
            "question": question,
            "role": role,
            "category_filter": "",
            "department_filter": "",
            "spend_summary": {},
            "savings_ops": [],
            "budget_alerts": [],
            "analysis": "",
            "retrieved_docs": [],
            "response": "",
            "recommended_action": "",
            "trace": agents.Trace(),
        }

    def test_keyword_match_category(self):
        import agents
        state = self._make_state("What's driving our IT & Software spend?")
        result = agents.orchestrator(state)
        assert result["category_filter"] == "IT & Software"

    def test_keyword_match_department(self):
        import agents
        state = self._make_state("Why is Manufacturing Operations over budget?")
        result = agents.orchestrator(state)
        assert result["department_filter"] == "Manufacturing Operations"

    def test_keyword_match_mro(self):
        import agents
        state = self._make_state("Where can we find savings in MRO Supplies?")
        result = agents.orchestrator(state)
        assert result["category_filter"] == "MRO Supplies"

    def test_no_match_returns_empty(self):
        import agents
        state = self._make_state("What is the weather today?")
        result = agents.orchestrator(state)
        assert result["category_filter"] == ""
        assert result["department_filter"] == ""

    def test_trace_logged(self):
        import agents
        state = self._make_state("Tell me about Logistics & Freight")
        result = agents.orchestrator(state)
        assert len(result["trace"].events) >= 1
        assert result["trace"].events[0]["agent"] == "orchestrator"

    def test_longer_department_name_matched_first(self):
        import agents
        state = self._make_state("What about Manufacturing Operations IT costs?")
        result = agents.orchestrator(state)
        assert result["department_filter"] == "Manufacturing Operations"


class TestAllowedTables:
    """Test data_access whitelist validation (SQL injection prevention)."""

    def test_valid_tables_in_whitelist(self):
        import data_access
        for table in data_access.ALLOWED_TABLES:
            assert table in data_access.ALLOWED_TABLES

    def test_invalid_table_rejected(self):
        import data_access
        with pytest.raises(ValueError, match="Unknown table"):
            data_access.get_table("malicious_table")

    def test_sql_injection_rejected(self):
        import data_access
        with pytest.raises(ValueError):
            data_access.get_table("gold_spend; DROP TABLE users")

    def test_all_six_tables_in_whitelist(self):
        import data_access
        expected = {
            "gold_spend_by_category_month",
            "gold_spend_by_vendor",
            "gold_budget_variance",
            "gold_maverick_spend",
            "gold_savings_opportunities",
            "gold_finance_documents",
        }
        assert data_access.ALLOWED_TABLES == expected


class TestRoutingResponseParsing:
    """Test model_client routing response JSON parsing."""

    def test_parse_clean_json(self):
        import model_client
        result = model_client._LLMClient._parse_routing_response(
            '{"category": "IT & Software", "department": ""}'
        )
        assert result == {"category": "IT & Software", "department": ""}

    def test_parse_json_with_markdown_fence(self):
        import model_client
        result = model_client._LLMClient._parse_routing_response(
            '```json\n{"category": "MRO Supplies", "department": ""}\n```'
        )
        assert result == {"category": "MRO Supplies", "department": ""}

    def test_parse_json_with_plain_fence(self):
        import model_client
        result = model_client._LLMClient._parse_routing_response(
            '```\n{"category": "", "department": "Finance"}\n```'
        )
        assert result == {"category": "", "department": "Finance"}

    def test_parse_invalid_json_returns_empty(self):
        import model_client
        result = model_client._LLMClient._parse_routing_response("not json at all")
        assert result == {"category": "", "department": ""}

    def test_parse_missing_keys_returns_empty(self):
        import model_client
        result = model_client._LLMClient._parse_routing_response('{"foo": "bar"}')
        assert result == {"category": "", "department": ""}


class TestAnalyticsFormatting:
    """Test analytics_agent formatting logic."""

    def _make_state_with_data(self, **overrides):
        import agents
        state = {
            "session_id": "test-456",
            "question": "test question",
            "role": "analyst",
            "category_filter": "",
            "department_filter": "",
            "spend_summary": {
                "by_category_recent": {"IT & Software": 50000, "Marketing": 30000},
                "top_vendors": [],
                "maverick_pct": 12.7,
            },
            "savings_ops": [
                {"opportunity_type": "Vendor Consolidation", "category_name": "IT & Software",
                 "description": "Consolidate 3 vendors into preferred", "estimated_annual_savings": 15000},
            ],
            "budget_alerts": [
                {"department_name": "IT", "month": datetime.datetime(2024, 1, 1),
                 "variance_pct": 15, "variance_amount": 5000},
            ],
            "analysis": "",
            "retrieved_docs": [],
            "response": "",
            "recommended_action": "",
            "trace": agents.Trace(),
        }
        state.update(overrides)
        return state

    def test_maverick_appears_in_analysis(self):
        import agents
        state = self._make_state_with_data()
        result = agents.analytics_agent(state)
        analysis = result["analysis"]
        assert "maverick" in analysis.lower()
        pct_sign = chr(37)  # avoid pytest rewrite issue with literal %
        assert f"13{pct_sign}" in analysis

    def test_savings_ops_in_analysis(self):
        import agents
        state = self._make_state_with_data()
        result = agents.analytics_agent(state)
        assert "Vendor Consolidation" in result["analysis"]
        assert "15,000" in result["analysis"]

    def test_empty_spend_summary_returns_no_data(self):
        import agents
        state = self._make_state_with_data(spend_summary={})
        result = agents.analytics_agent(state)
        assert "No data available" in result["analysis"]

    def test_budget_alerts_in_analysis(self):
        import agents
        state = self._make_state_with_data()
        result = agents.analytics_agent(state)
        assert "Budget alert" in result["analysis"]
        assert "IT" in result["analysis"]

    def test_trace_logged_on_success(self):
        import agents
        state = self._make_state_with_data()
        result = agents.analytics_agent(state)
        assert any(e["agent"] == "analytics_agent" for e in result["trace"].events)


class TestTrace:
    """Test the Trace observability class."""

    def test_trace_logs_events(self):
        import agents
        trace = agents.Trace()
        trace.log("test_agent", "test message")
        assert len(trace.events) == 1
        assert trace.events[0]["agent"] == "test_agent"
        assert trace.events[0]["msg"] == "test message"
        assert "t" in trace.events[0]

    def test_trace_multiple_events(self):
        import agents
        trace = agents.Trace()
        trace.log("agent1", "msg1")
        trace.log("agent2", "msg2")
        trace.log("agent3", "msg3")
        assert len(trace.events) == 3

    def test_trace_timestamps_ordered(self):
        import agents
        trace = agents.Trace()
        trace.log("a", "first")
        trace.log("b", "second")
        assert trace.events[0]["t"] <= trace.events[1]["t"]


def test_maverick_standalone():
    """Standalone test to isolate maverick assertion from class fixtures."""
    import agents
    import datetime
    state = {
        "session_id": "test-standalone",
        "question": "test question",
        "role": "analyst",
        "category_filter": "",
        "department_filter": "",
        "spend_summary": {
            "by_category_recent": {"IT & Software": 50000, "Marketing": 30000},
            "top_vendors": [],
            "maverick_pct": 12.7,
        },
        "savings_ops": [
            {"opportunity_type": "Vendor Consolidation", "category_name": "IT & Software",
             "description": "Consolidate 3 vendors", "estimated_annual_savings": 15000},
        ],
        "budget_alerts": [
            {"department_name": "IT", "month": datetime.datetime(2024, 1, 1),
             "variance_pct": 15, "variance_amount": 5000},
        ],
        "analysis": "",
        "retrieved_docs": [],
        "response": "",
        "recommended_action": "",
        "trace": agents.Trace(),
    }
    result = agents.analytics_agent(state)
    assert "maverick" in result["analysis"].lower()
    assert "13%" in result["analysis"]
