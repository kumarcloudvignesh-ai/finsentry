"""
FinSentry multi-agent pipeline (LangGraph), following the architecture:

    Orchestrator -> Data Agent -> Analytics Agent -> RAG Agent -> Action Agent -> Response

Each node is deliberately small and single-purpose so it maps 1:1 onto the
diagram. Swap-in points for the real Databricks services live in the
sibling modules:
    data_access.py   -> Lakehouse / Gold tables (Unity Catalog)
    vector_store.py  -> Vector Search (RAG)
    model_client.py  -> Model Serving
    memory_store.py  -> Lakebase (agent memory)

Governance (Unity Catalog ABAC/RBAC) is represented at the app layer by
check_permission() -- in production this is enforced for real by Unity
Catalog row/column masking on the Gold tables themselves; the app-level
check additionally lets us tailor what the agent is willing to discuss
per role.
"""

import logging
import time
import uuid
from typing import TypedDict, List

from langgraph.graph import StateGraph, END

import data_access
import memory_store
import model_client
import observability
import vector_store

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Observability -- structured trace of every agent step (mirrors what you'd
# ship to Lakehouse Monitoring / an `agent_traces` Delta table in production)
# ---------------------------------------------------------------------------
class Trace:
    def __init__(self):
        self.events: List[dict] = []

    def log(self, agent: str, message: str):
        self.events.append({"t": time.time(), "agent": agent, "msg": message})


# ---------------------------------------------------------------------------
# Unity Catalog-style role gate (app-layer view on top of UC governance)
# ---------------------------------------------------------------------------
ROLE_CATEGORY_ACCESS = {
    "analyst": {"Raw Materials", "Logistics & Freight", "IT & Software", "Professional Services",
                "Travel & Entertainment", "MRO Supplies", "Marketing", "Facilities & Utilities"},
    "exec": "ALL",
}


def check_permission(role: str, category_name: str) -> bool:
    allowed = ROLE_CATEGORY_ACCESS.get(role)
    return allowed == "ALL" or (allowed is not None and category_name in allowed)


# ---------------------------------------------------------------------------
# Graph state
# ---------------------------------------------------------------------------
class AgentState(TypedDict):
    session_id: str
    question: str
    role: str
    category_filter: str          # "" means "all categories the role can see"
    department_filter: str        # "" means "no specific department asked about"
    spend_summary: dict
    savings_ops: list
    budget_alerts: list
    analysis: str
    retrieved_docs: list
    response: str
    recommended_action: str
    trace: Trace
    llm_calls: List[dict]    # observability: per-call info from route_intent + generate


# ---------------------------------------------------------------------------
# Node 1: Orchestrator -- LLM-based intent routing with keyword fallback.
# Tries model_client.route_intent() first; falls back to keyword matching
# when no LLM backend is configured or the call fails.
# ---------------------------------------------------------------------------
CATEGORY_NAMES = [
    "Raw Materials", "Logistics & Freight", "IT & Software", "Professional Services",
    "Travel & Entertainment", "MRO Supplies", "Marketing", "Facilities & Utilities",
]
DEPARTMENT_NAMES = [
    "Manufacturing Operations", "Supply Chain", "IT", "Sales & Marketing",
    "R&D", "Finance", "HR", "Facilities",
]
# Which spend categories each department is a primary buyer in -- used to
# scope savings opportunities to the department actually asked about.
DEPARTMENT_CATEGORY_HINTS = {
    "Manufacturing Operations": {"Raw Materials", "Logistics & Freight", "MRO Supplies", "Facilities & Utilities"},
    "Supply Chain": {"Logistics & Freight", "Raw Materials", "MRO Supplies", "Facilities & Utilities"},
    "IT": {"IT & Software", "Professional Services"},
    "Sales & Marketing": {"Marketing", "Travel & Entertainment", "Professional Services"},
    "R&D": {"Professional Services", "IT & Software", "Raw Materials", "MRO Supplies"},
    "Finance": {"Professional Services", "IT & Software"},
    "HR": {"Professional Services", "Travel & Entertainment", "IT & Software"},
    "Facilities": {"Facilities & Utilities", "MRO Supplies"},
}


def orchestrator(state: AgentState) -> AgentState:
    # Try LLM-based routing first
    routing = model_client.route_intent(
        state["question"], CATEGORY_NAMES, DEPARTMENT_NAMES
    )
    # Capture LLM call info for observability
    routing_call_info = model_client.get_last_call_info()
    state["llm_calls"].append({"call_type": "routing", **routing_call_info})

    matched_cat = routing.get("category", "")
    matched_dept = routing.get("department", "")

    # Fall back to keyword matching when LLM routing is unavailable or returns empty
    if not matched_cat and not matched_dept:
        q_lower = state["question"].lower()
        matched_cat = next((c for c in CATEGORY_NAMES if c.lower() in q_lower), "")
        # match longer names first so e.g. "Manufacturing Operations" beats a bare "IT" substring
        matched_dept = next((d for d in sorted(DEPARTMENT_NAMES, key=len, reverse=True) if d.lower() in q_lower), "")
        route_method = "keyword"
    else:
        route_method = "llm"

    state["category_filter"] = matched_cat
    state["department_filter"] = matched_dept
    state["trace"].log("orchestrator", f"question='{state['question']}' category='{matched_cat}' department='{matched_dept}' route={route_method}")
    return state


# ---------------------------------------------------------------------------
# Node 2: Data Agent -- pulls governed structured data from the Gold layer
# ---------------------------------------------------------------------------
def data_agent(state: AgentState) -> AgentState:
    try:
        cat_month = data_access.spend_by_category_month()
        vendors = data_access.spend_by_vendor()
        budget = data_access.budget_variance()
        maverick = data_access.maverick_spend()
        savings = data_access.savings_opportunities()

        role = state["role"]
        if not check_permission(role, state["category_filter"]) and state["category_filter"]:
            state["spend_summary"] = {}
            state["savings_ops"] = []
            state["budget_alerts"] = []
            state["trace"].log("data_agent", f"permission denied for role={role} category={state['category_filter']}")
            return state

        allowed = ROLE_CATEGORY_ACCESS.get(role)
        if allowed != "ALL":
            cat_month = cat_month[cat_month["category_name"].isin(allowed)]
            vendors = vendors[vendors["category_name"].isin(allowed)]
            savings = savings[savings["category_name"].isin(allowed)]

        if state["category_filter"]:
            cat_month = cat_month[cat_month["category_name"] == state["category_filter"]]
            vendors = vendors[vendors["category_name"] == state["category_filter"]]
            savings = savings[savings["category_name"] == state["category_filter"]]
        elif state["department_filter"]:
            dept_cats = DEPARTMENT_CATEGORY_HINTS.get(state["department_filter"])
            if dept_cats:
                cat_month = cat_month[cat_month["category_name"].isin(dept_cats)]
                vendors = vendors[vendors["category_name"].isin(dept_cats)]
                savings = savings[savings["category_name"].isin(dept_cats)]

        latest_two = sorted(cat_month["month"].unique())[-2:] if len(cat_month) else []
        trend = cat_month[cat_month["month"].isin(latest_two)] if len(latest_two) == 2 else cat_month

        maverick_total = maverick["total_spend"].sum()
        maverick_pct = maverick["no_po_spend"].sum() / maverick_total * 100 if maverick_total > 0 else 0.0

        state["spend_summary"] = {
            "by_category_recent": trend.groupby("category_name")["total_spend"].sum().round(0).to_dict(),
            "top_vendors": vendors.sort_values("vendor_spend", ascending=False).head(5)[
                ["vendor_name", "category_name", "vendor_spend", "pct_of_category", "preferred_vendor"]
            ].to_dict("records"),
            "maverick_pct": round(maverick_pct, 1),
        }
        state["savings_ops"] = savings.sort_values("estimated_annual_savings", ascending=False).head(5).to_dict("records")

        if state["department_filter"]:
            dept_budget = budget[budget["department_name"] == state["department_filter"]].sort_values("month")
            overrun = dept_budget[dept_budget["variance_pct"] > 8]
            state["budget_alerts"] = overrun.tail(3)[
                ["department_name", "month", "variance_pct", "variance_amount"]
            ].to_dict("records")
        else:
            overrun = budget[budget["variance_pct"] > 8]
            state["budget_alerts"] = overrun.sort_values("variance_pct", ascending=False).head(3)[
                ["department_name", "month", "variance_pct", "variance_amount"]
            ].to_dict("records")

        state["trace"].log("data_agent", f"pulled data from {data_access.data_source_label()}")
    except Exception as e:
        logger.error("data_agent failed: %s", e, exc_info=True)
        state["trace"].log("data_agent", f"ERROR: {e}")
        state["spend_summary"] = {}
        state["savings_ops"] = []
        state["budget_alerts"] = []
    return state


# ---------------------------------------------------------------------------
# Node 3: Analytics Agent -- turns raw numbers into a plain-language finding
# ---------------------------------------------------------------------------
def analytics_agent(state: AgentState) -> AgentState:
    if not state["spend_summary"]:
        state["analysis"] = "No data available for this question (permission denied or no matching category)."
        state["trace"].log("analytics_agent", "no data to analyze")
        return state

    try:
        lines = []

        if state["department_filter"]:
            dept = state["department_filter"]
            if state["budget_alerts"]:
                for alert in state["budget_alerts"]:
                    lines.append(f"{dept} was {alert['variance_pct']}% over budget in {alert['month']:%b %Y} "
                                  f"(+${alert['variance_amount']:,.0f}).")
            else:
                lines.append(f"{dept} has not exceeded its monthly budget by more than 8% in the dataset.")

        by_cat = state["spend_summary"]["by_category_recent"]
        if by_cat and not state["department_filter"]:
            top_cat = max(by_cat, key=by_cat.get)
            lines.append(f"Largest recent spend category: {top_cat} (${by_cat[top_cat]:,.0f} over the latest 2 months).")

        maverick_pct = state["spend_summary"].get("maverick_pct", 0)
        if maverick_pct > 0:
            lines.append(f"Spend without a PO (maverick spend): {maverick_pct:.0f}% of total.")

        for op in state["savings_ops"][:3]:
            lines.append(f"[{op['opportunity_type']}] {op['category_name']}: {op['description']} "
                          f"(~${op['estimated_annual_savings']:,.0f}/yr estimated).")

        if not state["department_filter"]:
            for alert in state["budget_alerts"]:
                lines.append(f"Budget alert: {alert['department_name']} was {alert['variance_pct']}% over budget "
                              f"in {alert['month']:%b %Y} (+${alert['variance_amount']:,.0f}).")

        state["analysis"] = " ".join(lines) if lines else "No notable variances or savings opportunities found."
        state["trace"].log("analytics_agent", state["analysis"][:200])
    except Exception as e:
        logger.error("analytics_agent failed: %s", e, exc_info=True)
        state["trace"].log("analytics_agent", f"ERROR: {e}")
        state["analysis"] = "Analysis could not be completed due to an error."
    return state


# ---------------------------------------------------------------------------
# Node 4: RAG Agent -- grounds the answer in policy / contract / narrative docs
# ---------------------------------------------------------------------------
def rag_agent(state: AgentState) -> AgentState:
    if not state["spend_summary"]:
        state["retrieved_docs"] = []
        return state
    try:
        docs = vector_store.search(state["question"], k=3)
        state["retrieved_docs"] = docs
        state["trace"].log("rag_agent", f"retrieved {len(docs)} doc chunks")
    except Exception as e:
        logger.error("rag_agent failed: %s", e, exc_info=True)
        state["trace"].log("rag_agent", f"ERROR: {e}")
        state["retrieved_docs"] = []
    return state


# ---------------------------------------------------------------------------
# Node 5: Action Agent -- synthesizes the final answer, writes memory,
# proposes a recommended next action
# ---------------------------------------------------------------------------
def action_agent(state: AgentState) -> AgentState:
    try:
        # Load recent conversation context from memory for short-term recall
        recent = memory_store.recent_events(state["session_id"], limit=3)
        memory_context = "\n".join(f"- Q: {e['question']} A: {e['response']}" for e in recent) if recent else ""

        doc_context = "\n".join(f"- ({d['source']}) {d['text']}" for d in state["retrieved_docs"])
        prompt = (
            f"User question: {state['question']}\n\n"
            f"Structured spend analysis:\n{state['analysis']}\n\n"
            f"Relevant policy/contract excerpts:\n{doc_context or '(none retrieved)'}\n\n"
        )
        if memory_context:
            prompt += f"Recent conversation context:\n{memory_context}\n\n"
        prompt += (
            f"Write a concise answer for a '{state['role']}' user, grounded only in the "
            f"analysis and excerpts above, ending with one recommended action."
        )
        response = model_client.generate(prompt)
        # Capture LLM call info for observability
        gen_call_info = model_client.get_last_call_info()
        state["llm_calls"].append({"call_type": "generation", **gen_call_info})

        state["response"] = response
        state["recommended_action"] = (
            state["savings_ops"][0]["description"] if state["savings_ops"] else "No specific action recommended."
        )

        memory_store.record_event(state["session_id"], state["question"], state["analysis"], response)
        state["trace"].log("action_agent", f"answer generated via {model_client.active_backend()}; memory written to {memory_store.backend_label()}")
    except Exception as e:
        logger.error("action_agent failed: %s", e, exc_info=True)
        state["trace"].log("action_agent", f"ERROR: {e}")
        state["response"] = "An error occurred while generating the response."
        state["recommended_action"] = "No specific action recommended."
    return state


# ---------------------------------------------------------------------------
# Build + compile the graph
# ---------------------------------------------------------------------------
_graph = StateGraph(AgentState)
_graph.add_node("orchestrator", orchestrator)
_graph.add_node("data_agent", data_agent)
_graph.add_node("analytics_agent", analytics_agent)
_graph.add_node("rag_agent", rag_agent)
_graph.add_node("action_agent", action_agent)

_graph.set_entry_point("orchestrator")
_graph.add_edge("orchestrator", "data_agent")
_graph.add_edge("data_agent", "analytics_agent")
_graph.add_edge("analytics_agent", "rag_agent")
_graph.add_edge("rag_agent", "action_agent")
_graph.add_edge("action_agent", END)

app_graph = _graph.compile()


def ask(question: str, role: str = "analyst", session_id: str = None) -> AgentState:
    """Single entry point used by the Streamlit app."""
    t_start = time.time()
    state: AgentState = {
        "session_id": session_id or str(uuid.uuid4()),
        "question": question,
        "role": role,
        "category_filter": "",
        "department_filter": "",
        "spend_summary": {},
        "savings_ops": [],
        "budget_alerts": [],
        "analysis": "",
        "retrieved_docs": [],
        "response": "",
        "recommended_action": "",
        "trace": Trace(),
        "llm_calls": [],
    }
    result = app_graph.invoke(state)
    total_duration_ms = (time.time() - t_start) * 1000

    # Persist trace events to structured logging
    for event in result["trace"].events:
        logger.info("trace: agent=%s msg=%s", event["agent"], event["msg"])

    # Persist run + LLM calls to the observability store
    try:
        run_id = observability.record_run(
            session_id=result["session_id"],
            question=result["question"],
            role=result["role"],
            category_filter=result["category_filter"],
            department_filter=result["department_filter"],
            response=result["response"],
            recommended_action=result["recommended_action"],
            total_duration_ms=round(total_duration_ms, 1),
            trace_events=result["trace"].events,
        )
        for i, call in enumerate(result["llm_calls"]):
            observability.record_llm_call(
                run_id=run_id,
                call_order=i + 1,
                call_type=call.get("call_type", "unknown"),
                backend=call.get("backend", "unknown"),
                model=call.get("model", ""),
                prompt_tokens=call.get("prompt_tokens", 0),
                completion_tokens=call.get("completion_tokens", 0),
                total_tokens=call.get("total_tokens", 0),
                duration_ms=call.get("duration_ms", 0.0),
            )
        result["trace"].log("observability", f"run persisted (run_id={run_id[:8]}...; {len(result['llm_calls'])} LLM calls)")
    except Exception as e:
        logger.error("observability persistence failed: %s", e, exc_info=True)
        result["trace"].log("observability", f"ERROR persisting run: {e}")

    return result


if __name__ == "__main__":
    for q in [
        "What's driving our IT & Software spend?",
        "Where can we find savings in MRO Supplies?",
        "Why is Manufacturing Operations over budget?",
    ]:
        print("=" * 80)
        print("Q:", q)
        result = ask(q, role="analyst")
        print("A:", result["response"])
        print("Recommended action:", result["recommended_action"])
        print(f"Trace steps: {len(result['trace'].events)}")
