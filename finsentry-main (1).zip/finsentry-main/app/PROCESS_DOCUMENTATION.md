# FinSentry -- End-to-End Process Documentation

## Architecture Overview

FinSentry is a spend intelligence application built on Databricks with two primary user surfaces:

1. **Spend Overview Dashboard** -- a Streamlit tab that reads Gold tables directly
2. **Ask FinSentry** -- a conversational AI tab backed by a 5-node LangGraph agent pipeline

The system has six Python modules, each with a single responsibility:

| Module | Responsibility | Databricks Service (Production) | Local Fallback |
| --- | --- | --- | --- |
| `streamlit_app.py` | UI layer (two tabs, role selector, chat interface) | Databricks Apps | `streamlit run` locally |
| `agents.py` | LangGraph pipeline orchestration (5 nodes) | Runs in App container | Runs locally |
| `data_access.py` | Read Gold spend tables | Unity Catalog via Databricks SDK | Local Parquet files |
| `model_client.py` | LLM calls (generation + routing) | Databricks Model Serving (Foundation Model APIs) | Direct Anthropic API or offline template |
| `vector_store.py` | Semantic document retrieval (RAG) | Databricks Vector Search (Delta Sync index) | Local TF-IDF cosine similarity |
| `memory_store.py` | Agent conversation memory (short-term + long-term) | Databricks Lakebase (managed Postgres) | Local SQLite file |

---

## PART 1: Dashboard Load Flow (Spend Overview Tab)

When a user opens the FinSentry app or switches to the "Spend Overview" tab, the following sequence executes:

### Step 1: Page Configuration and Sidebar Initialization

**File:** `streamlit_app.py`, lines 25-39

Streamlit renders the page with `st.set_page_config()`, then builds the sidebar:

1. The **role selector** (`st.selectbox`) renders with two options: `analyst` and `exec`. This role value is passed to every agent call later and drives the Unity Catalog-style permission gate.
2. Three **service status labels** are displayed by calling each module's label function:
   - `data_access.data_source_label()` -- returns either `"Databricks SQL Warehouse (finsentry.spend_analytics)"` or `"local demo data (data/gold/*.parquet)"` depending on whether `DATABRICKS_HTTP_PATH` is set.
   - `model_client.active_backend()` -- returns `"Databricks Model Serving (...)"`, `"Anthropic API (...)"`, or `"offline template (no LLM configured)"` based on credential availability.
   - `memory_store.backend_label()` -- returns `"Databricks Lakebase (Postgres)"` or `"local SQLite (...)"` depending on whether `LAKEBASE_CONNECTION_STRING` is set.

**Key point:** These calls are cheap (just string formatting), but they trigger lazy credential discovery in `model_client._LLMClient` that may instantiate a `WorkspaceClient` on first access.

### Step 2: Cached Data Loading

**File:** `streamlit_app.py`, lines 45-53

The function `_load_dashboard_data()` is decorated with `@st.cache_data(ttl=300)`, meaning the results are cached for 5 minutes and reused across Streamlit reruns (caused by any widget interaction).

On the **first load** (or after cache expiry), this function calls five data accessors in sequence:

```
_load_dashboard_data()
  -> data_access.spend_by_category_month()    -> get_table("gold_spend_by_category_month")
  -> data_access.spend_by_vendor()              -> get_table("gold_spend_by_vendor")
  -> data_access.budget_variance()             -> get_table("gold_budget_variance")
  -> data_access.maverick_spend()              -> get_table("gold_maverick_spend")
  -> data_access.savings_opportunities()        -> get_table("gold_savings_opportunities")
```

Each `get_table()` call (in `data_access.py`, line 115-119) does the following:

1. **Validates** the table name against `ALLOWED_TABLES` (a frozenset whitelist of 6 table names). If the name is not in the whitelist, raises `ValueError` -- this prevents SQL injection.
2. **Branches** based on `USE_DATABRICKS` (True when `DATABRICKS_HTTP_PATH` env var is set):
   - **Databricks mode:** Calls `_query_databricks(table)` which creates a `WorkspaceClient()` (auto-detects OAuth credentials in Databricks Apps), executes `SELECT * FROM finsentry.spend_analytics.{table}` via `w.statement_execution.execute_statement()` against a SQL Warehouse, and converts the result to a pandas DataFrame.
   - **Local mode:** Calls `_read_local(table)` which reads `{FINSENTRY_DATA_DIR}/data/gold/{table}.parquet` using `pd.read_parquet()`.

### Step 3: KPI Computation

**File:** `streamlit_app.py`, lines 66-81

After the five DataFrames are loaded, four KPI metrics are computed:

| KPI | Computation |
| --- | --- |
| Total spend (24 mo) | `cat_month["total_spend"].sum()` |
| Identified savings potential | `savings["estimated_annual_savings"].sum()` |
| Dept-months over budget (>8%) | `(budget["variance_pct"] > 8).sum()` |
| Spend without a PO (maverick %) | `maverick["no_po_spend"].sum() / maverick["total_spend"].sum() * 100` (with zero-division guard) |

These are rendered as `st.metric()` cards in a 4-column layout.

### Step 4: Chart and Table Rendering

**File:** `streamlit_app.py`, lines 84-117

Two columns are rendered side by side:

**Left column (60% width):**
- **Monthly spend by category line chart** -- pivots `cat_month` by month (rows) and category_name (columns), fills NaNs with 0, renders via `st.line_chart()`.
- **Savings opportunities table** -- sorts savings by `estimated_annual_savings` descending, selects and renames 4 columns, renders via `st.dataframe()`.

**Right column (40% width):**
- **Top vendors table** -- sorts vendors by `vendor_spend` descending, takes top 10, selects and renames 5 columns.
- **Recent budget alerts table** -- filters budget where `variance_pct > 8`, sorts descending, takes top 8.

**Important:** No agents or LLM calls are invoked during dashboard load. The dashboard reads Gold tables directly through `data_access.py`. The agent pipeline is only triggered when the user asks a question in the chat tab.

---

## PART 2: Conversational AI Flow (Ask FinSentry Tab)

When the user types a question (or clicks a suggestion button), a multi-step agent pipeline executes. Here is the complete end-to-end flow:

### Step 1: Session Initialization

**File:** `streamlit_app.py`, lines 128-132

On first visit, Streamlit initializes two session state keys:
- `session_id` -- a UUID v4 generated once per browser session, reused for all questions in that session. This becomes the `session_id` in the agent state and is the key used to store/retrieve conversation memory.
- `messages` -- an empty list that accumulates the chat history for display.

Previous messages are replayed from `st.session_state.messages` so the user sees the conversation history on rerun.

### Step 2: User Input Capture

**File:** `streamlit_app.py`, lines 138-155

Three suggestion buttons are rendered (the same three demo questions). If the user clicks one, it takes priority; otherwise the `st.chat_input()` value is used. The question is immediately appended to `st.session_state.messages` as a user message and rendered in the chat UI.

### Step 3: Agent Pipeline Invocation

**File:** `streamlit_app.py`, lines 157-159

A spinner displays "Routing through Orchestrator -> Data -> Analytics -> RAG -> Action..." while the following call executes:

```python
result = agents.ask(question, role=role, session_id=st.session_state.session_id)
```

This is the single entry point. Inside `agents.ask()` (line 329), a fresh `AgentState` TypedDict is constructed with the question, role, session_id, empty defaults for all data fields, and a new `Trace()` object.

The state is then passed to `app_graph.invoke(state)` which runs the LangGraph state machine.

### Step 4: LangGraph Execution -- Node by Node

The graph is a linear pipeline compiled at module load time (lines 312-326):

```
orchestrator -> data_agent -> analytics_agent -> rag_agent -> action_agent -> END
```

Each node receives the full `AgentState` dict, mutates it, and returns it to the graph runner. The state flows through all five nodes sequentially. Below is what each node does:

---

#### Node 1: Orchestrator (Intent Routing)

**File:** `agents.py`, lines 108-129

**Purpose:** Determine which spend category and/or department the user's question is about, so downstream nodes can filter data accordingly.

**Execution flow:**

1. Calls `model_client.route_intent(question, CATEGORY_NAMES, DEPARTMENT_NAMES)`.

2. Inside `model_client.py` (line 211), `route_intent()` builds a prompt listing available categories and departments, then calls the LLM with a `ROUTING_SYSTEM_PROMPT` that instructs it to return ONLY a JSON object with `category` and `department` keys.

3. The LLM backend selection follows the same priority as `generate()`:
   - **Databricks Foundation Model APIs** (if `DATABRICKS_HOST` + token available): Uses the OpenAI-compatible client to call the configured model (default: `databricks-meta-llama-3-3-70b-instruct`). The call is wrapped in `_call_with_retry()` which retries up to 3 times with exponential backoff (1s, 2s, 4s).
   - **Anthropic API** (if `ANTHROPIC_API_KEY` set): Calls `claude-sonnet-4-20250514` directly. Same retry logic.
   - **Offline fallback**: Returns `{"category": "", "department": ""}` immediately (no LLM call).

4. The LLM's response text is parsed by `_parse_routing_response()` which strips markdown code fences via regex, then attempts `json.loads()`. If parsing fails, returns empty strings.

5. Back in `orchestrator()`, if both `matched_cat` and `matched_dept` are empty (LLM unavailable or returned empty), **keyword fallback** activates:
   - Scans the lowercased question for any `CATEGORY_NAMES` substring.
   - Scans for `DEPARTMENT_NAMES`, sorted longest-first so "Manufacturing Operations" matches before a bare "IT".
   - Sets `route_method = "keyword"`.

6. Results are written to state: `category_filter`, `department_filter`. A trace event is logged with the routing decision and method used.

**Output:** `category_filter` (string like "IT & Software" or ""), `department_filter` (string like "Manufacturing Operations" or "").

---

#### Node 2: Data Agent (Structured Data Retrieval)

**File:** `agents.py`, lines 135-202

**Purpose:** Pull governed structured data from the Gold layer, filtered by the orchestrator's category/department selection and the user's role permissions.

**Execution flow:**

1. Calls all five data accessors from `data_access.py` (same functions used by the dashboard):
   - `spend_by_category_month()` -- monthly spend per category
   - `spend_by_vendor()` -- vendor-level spend with preferred-vendor flags
   - `budget_variance()` -- department-month budget vs actual, with variance %
   - `maverick_spend()` -- spend without a purchase order
   - `savings_opportunities()` -- identified savings actions with estimated annual savings

2. **Permission gate:** If the user's role does not have access to the filtered category (`check_permission()` returns False and a category filter is set), the node returns empty state and skips all further data processing.

3. **Role-based filtering:** For the `analyst` role, all DataFrames are filtered to only include categories in `ROLE_CATEGORY_ACCESS["analyst"]` (8 spend categories). The `exec` role gets `"ALL"` (no filtering).

4. **Category/department filtering:**
   - If `category_filter` is set: filter all DataFrames to that single category.
   - Else if `department_filter` is set: filter to the `DEPARTMENT_CATEGORY_HINTS` for that department (a predefined mapping of which spend categories each department primarily buys in).

5. **Trend computation:** Takes the last 2 months from `cat_month` for recent trend analysis.

6. **Maverick spend calculation:** `no_po_spend / total_spend * 100` with zero-division guard.

7. **State population:**
   - `spend_summary` dict with: `by_category_recent` (category to spend for last 2 months), `top_vendors` (top 5 by spend), `maverick_pct`.
   - `savings_ops` list: top 5 savings opportunities sorted by estimated annual savings.
   - `budget_alerts` list: department-months where variance > 8%, either for the filtered department or the top 3 across all departments.

8. **Error handling:** The entire node body is wrapped in try/except. On any exception, logs the error with traceback, sets empty state, and continues the pipeline.

**Output:** `spend_summary` (dict), `savings_ops` (list), `budget_alerts` (list).

---

#### Node 3: Analytics Agent (Plain-Language Analysis)

**File:** `agents.py`, lines 208-250

**Purpose:** Convert the raw structured data from the Data Agent into a plain-language analysis string that the Action Agent can feed to the LLM.

**Execution flow:**

1. **Guard clause:** If `spend_summary` is empty (permission denied or no matching data), sets a "no data" analysis message and returns early.

2. **Department-specific analysis:** If a department filter is set, checks `budget_alerts` for that department and generates sentences like "Manufacturing Operations was 12% over budget in Oct 2024 (+$45,000)." If no alerts, states the department stayed within budget.

3. **Top category analysis:** If no department filter, finds the largest spend category from `by_category_recent` and generates "Largest recent spend category: IT & Software ($1,200,000 over the latest 2 months)."

4. **Maverick spend:** If `maverick_pct > 0`, adds "Spend without a PO (maverick spend): 23% of total."

5. **Savings opportunities:** Lists up to 3 top savings ops with type, category, description, and estimated annual savings.

6. **Budget alerts (global):** If no department filter, lists top budget alerts across all departments.

7. All sentences are joined into a single `analysis` string. Trace logs the first 200 characters.

8. **Error handling:** try/except wraps the body; on failure, sets a generic error analysis string.

**Output:** `analysis` (string, plain-language findings).

**Important:** This node performs NO LLM calls. It is pure Python string formatting over the structured data. The LLM is only called in the Action Agent.

---

#### Node 4: RAG Agent (Document Retrieval)

**File:** `agents.py`, lines 256-268

**Purpose:** Retrieve relevant policy/contract document chunks to ground the LLM's answer in company-specific rules.

**Execution flow:**

1. **Guard clause:** If `spend_summary` is empty, skips retrieval and returns empty docs.

2. Calls `vector_store.search(question, k=3)` which branches based on `data_access.USE_DATABRICKS`:

   **Databricks Vector Search mode** (`vector_store.py`, lines 58-87):
   - Creates a `WorkspaceClient()` to get OAuth credentials.
   - Extracts the Bearer token from `w.config.authenticate()`.
   - Initializes `VectorSearchClient` with the workspace URL and token.
   - Calls `index.similarity_search()` on the Delta Sync index (`finsentry.spend_analytics.finance_docs_index`) with the user's question, requesting 3 results with `text` and `source_file` columns.
   - Parses the response `data_array` into a list of dicts with `text`, `source`, and `score` keys.
   - On any exception, falls back to local TF-IDF search.

   **Local TF-IDF mode** (`vector_store.py`, lines 30-55):
   - Lazily builds a TF-IDF index from `gold_finance_documents` table on first call.
   - Transforms the query string into a TF-IDF vector.
   - Computes cosine similarity against all document chunks.
   - Returns the top-k chunks with non-zero similarity.

3. Stores results in `retrieved_docs` and logs the count.

4. **Error handling:** try/except wraps the body; on failure, sets `retrieved_docs = []`.

**Output:** `retrieved_docs` (list of dicts with `text`, `source`, `score`).

---

#### Node 5: Action Agent (LLM Synthesis + Memory)

**File:** `agents.py`, lines 275-306

**Purpose:** Synthesize the final natural-language answer using the LLM, incorporating structured analysis, retrieved documents, and short-term conversation memory. Also persist the interaction to long-term memory.

**Execution flow:**

1. **Short-term memory recall:** Calls `memory_store.recent_events(session_id, limit=3)` to retrieve the last 3 question-answer pairs for this session. This provides conversation context so the LLM can reference prior turns.

   - **Lakebase mode:** Connects to Postgres via `psycopg2` using `LAKEBASE_CONNECTION_STRING`, executes `SELECT question, response, ts FROM episodic_memory WHERE session_id = ? ORDER BY ts DESC LIMIT 3`.
   - **Local SQLite mode:** Same query against the SQLite file, which is auto-created on first use with the `episodic_memory` and `semantic_memory` tables.

2. **Prompt construction:** Builds a multi-section prompt:
   - User question
   - Structured spend analysis (from analytics agent)
   - Relevant policy/contract excerpts (from RAG agent, formatted as `"- (source) text"` per chunk)
   - Recent conversation context (from memory recall, formatted as `"- Q: ... A: ..."` per prior turn) -- only included if non-empty
   - Instructions: "Write a concise answer for a '{role}' user, grounded only in the analysis and excerpts above, ending with one recommended action."

3. **LLM generation:** Calls `model_client.generate(prompt)` which follows the backend priority chain:

   **Databricks Model Serving** (highest priority):
   - Uses the OpenAI-compatible client (`openai.OpenAI`) with `base_url = https://{host}/serving-endpoints`.
   - Calls `chat.completions.create()` with the system prompt (`SYSTEM_PROMPT`) and the user prompt.
   - System prompt instructs: "Answer using ONLY the structured spend analysis and retrieved excerpts. Be concise, cite concrete numbers, end with one recommended action. Never invent figures."
   - Model: `databricks-meta-llama-3-3-70b-instruct` (configurable via `DATABRICKS_SERVING_MODEL`).
   - Parameters: `max_tokens=400`, `temperature=0.0` (deterministic).
   - Wrapped in `_call_with_retry()` (3 attempts, exponential backoff: 1s, 2s, 4s).
   - Token usage is logged: `prompt_tokens`, `completion_tokens`, `total_tokens`.
   - On failure, falls through to next backend.

   **Anthropic API** (second priority):
   - Uses `anthropic.Anthropic()` client with `ANTHROPIC_API_KEY`.
   - Model: `claude-sonnet-4-20250514`.
   - Same retry logic and token logging.
   - On failure, falls through to offline.

   **Offline fallback** (always available):
   - Returns a template string: `[Offline mode -- set DATABRICKS_HOST/DATABRICKS_TOKEN or ANTHROPIC_API_KEY for a generated answer]` followed by the raw prompt.
   - No network calls. Deterministic output.

4. **Recommended action extraction:** Takes the top savings opportunity's description (if any), otherwise "No specific action recommended."

5. **Memory persistence:** Calls `memory_store.record_event(session_id, question, analysis, response)` to write the full interaction (question, analysis, response) into the `episodic_memory` table for future recall.

6. **Error handling:** try/except wraps the entire body. On failure, sets a generic error response and no-action recommendation.

**Output:** `response` (string, the LLM-generated answer), `recommended_action` (string).

---

### Step 5: Trace Persistence

**File:** `agents.py`, lines 346-349

After the graph completes, `agents.ask()` iterates over all `Trace` events accumulated during the pipeline run and logs each one via `logger.info("trace: agent=%s msg=%s", ...)`.

In production, these structured log entries can be captured by Databricks App logs and forwarded to a Lakehouse `agent_traces` Delta table for observability and debugging.

### Step 6: UI Rendering of the Answer

**File:** `streamlit_app.py`, lines 160-171

Back in the Streamlit app:

1. The `result["response"]` is rendered as markdown in an assistant chat message bubble.

2. An expandable "How this answer was produced" section shows:
   - **Recommended action** (from `result['recommended_action']`)
   - **Retrieved policy/contract context** -- each document chunk's source and first 200 characters of text.
   - **Agent trace** -- every trace event with the agent name and message, showing the full pipeline execution path for transparency.

3. The response is appended to `st.session_state.messages` as an assistant message for future reruns.

---

## PART 3: Data Flow Diagram (Text)

```
USER TYPES QUESTION IN CHAT TAB
        |
        v
streamlit_app.py: agents.ask(question, role, session_id)
        |
        v
agents.py: app_graph.invoke(state)  [LangGraph]
        |
        +---> Node 1: ORCHESTRATOR
        |       |
        |       +---> model_client.route_intent(question, categories, departments)
        |       |       |
        |       |       +---> [Databricks] OpenAI client -> chat.completions.create() -> JSON parse
        |       |       +---> [Anthropic]  anthropic.messages.create() -> JSON parse
        |       |       +---> [Offline]   return {"category":"", "department":""}
        |       |       |
        |       |       (fallback) keyword match if LLM returns empty
        |       |
        |       +---> state.category_filter, state.department_filter set
        |
        +---> Node 2: DATA AGENT
        |       |
        |       +---> data_access.spend_by_category_month()  -> Gold table / Parquet
        |       +---> data_access.spend_by_vendor()          -> Gold table / Parquet
        |       +---> data_access.budget_variance()         -> Gold table / Parquet
        |       +---> data_access.maverick_spend()            -> Gold table / Parquet
        |       +---> data_access.savings_opportunities()    -> Gold table / Parquet
        |       |
        |       +---> Role permission check (analyst: 8 categories, exec: all)
        |       +---> Filter by category_filter or department_filter
        |       +---> Compute maverick_pct, top vendors, budget alerts
        |       |
        |       +---> state.spend_summary, state.savings_ops, state.budget_alerts set
        |
        +---> Node 3: ANALYTICS AGENT
        |       |
        |       +---> (no LLM call -- pure Python string formatting)
        |       +---> Reads spend_summary, budget_alerts, savings_ops from state
        |       +---> Builds plain-language analysis sentences
        |       |
        |       +---> state.analysis set
        |
        +---> Node 4: RAG AGENT
        |       |
        |       +---> vector_store.search(question, k=3)
        |       |       |
        |       |       +---> [Databricks] VectorSearchClient -> similarity_search() -> Delta Sync index
        |       |       +---> [Local]     TF-IDF cosine similarity over gold_finance_documents
        |       |       |
        |       |       +---> (fallback) local TF-IDF if VS fails
        |       |
        |       +---> state.retrieved_docs set (list of {text, source, score})
        |
        +---> Node 5: ACTION AGENT
        |       |
        |       +---> memory_store.recent_events(session_id, limit=3)
        |       |       |
        |       |       +---> [Lakebase] psycopg2 -> SELECT from episodic_memory
        |       |       +---> [Local]   sqlite3 -> SELECT from episodic_memory
        |       |
        |       +---> Build prompt (question + analysis + docs + memory + instructions)
        |       |
        |       +---> model_client.generate(prompt)
        |       |       |
        |       |       +---> [Databricks] OpenAI client -> chat.completions.create() (retry x3)
        |       |       +---> [Anthropic]  anthropic.messages.create() (retry x3)
        |       |       +---> [Offline]   template string (no LLM)
        |       |
        |       +---> memory_store.record_event(session_id, question, analysis, response)
        |       |
        |       +---> state.response, state.recommended_action set
        |
        +---> END
        |
        v
agents.py: return result (full AgentState)
        |
        v
streamlit_app.py: render response in chat UI + trace expander
```

---

## PART 4: LLM Call Summary

There are exactly **two** points in the pipeline where an LLM is called:

| Call | Node | Function | Purpose | Model (Databricks) | Model (Anthropic) |
| --- | --- | --- | --- | --- | --- |
| 1 | Orchestrator | `model_client.route_intent()` | Classify question into category/department | `databricks-meta-llama-3-3-70b-instruct` | `claude-sonnet-4-20250514` |
| 2 | Action Agent | `model_client.generate()` | Generate final natural-language answer | `databricks-meta-llama-3-3-70b-instruct` | `claude-sonnet-4-20250514` |

All other nodes (Data Agent, Analytics Agent, RAG Agent) perform no LLM calls. The Data Agent reads SQL/Parquet, the Analytics Agent formats strings, and the RAG Agent does vector similarity search.

**Backend selection priority** (applied to both LLM calls):
1. Databricks Foundation Model APIs (auto-discovers host/token from Databricks SDK)
2. Direct Anthropic API (requires `ANTHROPIC_API_KEY`)
3. Offline deterministic template (no network, always available)

**Retry behavior:** Both LLM calls are wrapped in `_call_with_retry()` with 3 attempts and exponential backoff (1s, 2s, 4s delays). If all retries fail on the primary backend, the system falls through to the next backend in priority order.

---

## PART 5: Environment Variables Reference

| Variable | Required? | Used By | Purpose |
| --- | --- | --- | --- |
| `DATABRICKS_HOST` | No (auto-detected in Apps) | `model_client.py` | Databricks workspace host for LLM calls |
| `DATABRICKS_TOKEN` | No (auto-detected in Apps) | `model_client.py` | OAuth token for Model Serving API |
| `DATABRICKS_SERVING_MODEL` | No (default: `databricks-meta-llama-3-3-70b-instruct`) | `model_client.py` | Which Foundation Model to call |
| `ANTHROPIC_API_KEY` | No | `model_client.py` | Direct Anthropic API for local dev |
| `DATABRICKS_HTTP_PATH` | No (required for Databricks data mode) | `data_access.py` | SQL warehouse HTTP path; presence triggers Databricks data mode |
| `FINSENTRY_CATALOG` | No (default: `finsentry`) | `data_access.py` | Unity Catalog catalog name |
| `FINSENTRY_SCHEMA` | No (default: `spend_analytics`) | `data_access.py` | Unity Catalog schema name |
| `FINSENTRY_DATA_DIR` | No (default: workspace path) | `data_access.py`, `memory_store.py` | Base directory for local Parquet files and SQLite memory DB |
| `FINSENTRY_VS_ENDPOINT` | No (default: `finsentry_vs_endpoint`) | `vector_store.py` | Vector Search endpoint name |
| `FINSENTRY_VS_INDEX` | No (default: `finsentry.spend_analytics.finance_docs_index`) | `vector_store.py` | Vector Search index name |
| `LAKEBASE_CONNECTION_STRING` | No (required for Lakebase mode) | `memory_store.py` | Postgres DSN for Databricks Lakebase |

---

## PART 6: Error Handling and Graceful Degradation

Each agent node is wrapped in try/except with the following degradation strategy:

| Node | On Error | User Impact |
| --- | --- | --- |
| Orchestrator | Keyword fallback (no try/except needed -- `route_intent` already returns empty on failure) | Routing still works via keyword matching |
| Data Agent | Empty `spend_summary`, `savings_ops`, `budget_alerts` | Analytics agent will show "No data available" message |
| Analytics Agent | Generic error analysis string | Action agent still attempts LLM generation with the error message |
| RAG Agent | Empty `retrieved_docs` list | Action agent proceeds without document grounding (prompt says "none retrieved") |
| Action Agent | Generic error response, no recommended action | User sees error message; memory is not written |

This design ensures that a failure in any single node does not crash the pipeline -- the user always gets some form of response, even if degraded.

---

## PART 7: Observability Architecture

FinSentry includes a built-in observability layer that traces every agent pipeline run end-to-end and records LLM call details (backend, model, token usage, latency) for cost analysis and debugging.

### Module: `observability.py`

A new module dedicated to persisting and querying observability data. It follows a three-mode storage pattern:

| Mode | Storage | Trigger |
| --- | --- | --- |
| Databricks Unity Catalog (production) | Delta tables in `{CATALOG}.{SCHEMA}` via Databricks SDK statement execution API | `DATABRICKS_HTTP_PATH` env var set |
| Databricks Lakebase | Managed Postgres via `psycopg2` | `LAKEBASE_CONNECTION_STRING` env var set (and no `DATABRICKS_HTTP_PATH`) |
| Local (development) | SQLite file (`finsentry_observability.db`) | Default |

When Unity Catalog mode is active, observability data is written to two Delta tables:
- `finsentry.spend_analytics.agent_observability_runs`
- `finsentry.spend_analytics.agent_observability_llm_calls`

These tables are created automatically on first use via `CREATE TABLE IF NOT EXISTS ... USING DELTA`. All SQL is executed through the Databricks SDK `statement_execution` API using the same `WorkspaceClient` credential pattern as `data_access.py`. String values are escaped via `_sql_escape()` to prevent SQL injection in the dynamically constructed INSERT statements.

**Tables:**

`agent_runs` -- one row per `agents.ask()` invocation:

| Column | Type | Description |
| --- | --- | --- |
| `run_id` | TEXT (UUID) | Primary key, generated per run |
| `session_id` | TEXT | Browser session UUID from Streamlit |
| `ts` | DOUBLE | Unix timestamp of run completion |
| `question` | TEXT | User's original question |
| `role` | TEXT | User role (analyst / exec) |
| `category_filter` | TEXT | Orchestrator's category routing result |
| `department_filter` | TEXT | Orchestrator's department routing result |
| `response` | TEXT | Final LLM-generated answer |
| `recommended_action` | TEXT | Extracted recommended action |
| `total_duration_ms` | REAL | End-to-end pipeline duration in milliseconds |
| `num_trace_events` | INTEGER | Count of trace events recorded |
| `trace_json` | TEXT | Full trace events as JSON array |

`llm_calls` -- one row per LLM call within a run:

| Column | Type | Description |
| --- | --- | --- |
| `id` | INTEGER (auto) | Primary key |
| `run_id` | TEXT (FK) | Links to `agent_runs.run_id` |
| `call_order` | INTEGER | 1 = routing call, 2 = generation call |
| `call_type` | TEXT | "routing" or "generation" |
| `backend` | TEXT | "databricks", "anthropic", or "offline" |
| `model` | TEXT | Model name (e.g. `databricks-meta-llama-3-3-70b-instruct`) |
| `prompt_tokens` | INTEGER | Input tokens consumed |
| `completion_tokens` | INTEGER | Output tokens consumed |
| `total_tokens` | INTEGER | Sum of prompt + completion |
| `duration_ms` | REAL | LLM call latency in milliseconds |
| `ts` | DOUBLE | Unix timestamp of the call |

**Public functions:**

| Function | Returns | Purpose |
| --- | --- | --- |
| `record_run(...)` | `str` (run_id) | Persist a completed run with full trace |
| `record_llm_call(...)` | None | Persist a single LLM call's metadata |
| `get_recent_runs(limit=50)` | `list[dict]` | Recent runs for the table view |
| `get_run_trace(run_id)` | `list[dict]` | Full trace events for a specific run |
| `get_llm_calls_for_run(run_id)` | `list[dict]` | All LLM calls for a specific run |
| `get_llm_summary(limit=100)` | `dict` | Aggregate usage stats (totals, by backend, by call type) |
| `backend_label()` | `str` | Human-readable storage description |

### LLM Usage Tracking in `model_client.py`

The `_LLMClient` singleton now maintains a `last_call_info` dict that is updated after every LLM call:

```python
last_call_info = {
    "backend": "databricks" | "anthropic" | "offline",
    "model": "<model name>",
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_tokens": 0,
    "duration_ms": 0.0,
}
```

This is set in `_call_databricks()`, `_call_anthropic()`, and the offline fallback path. The public function `model_client.get_last_call_info()` returns a copy of this dict, which `agents.py` captures after each LLM call.

### Observability Data Flow in `agents.py`

1. **Orchestrator node:** After `model_client.route_intent()` returns, calls `model_client.get_last_call_info()` and appends it to `state["llm_calls"]` with `call_type: "routing"`.

2. **Action Agent node:** After `model_client.generate()` returns, calls `model_client.get_last_call_info()` and appends it to `state["llm_calls"]` with `call_type: "generation"`.

3. **`ask()` function:** After `app_graph.invoke()` completes:
   - Computes `total_duration_ms` from start/end timestamps.
   - Calls `observability.record_run()` with the full trace events (serialized to JSON) and run metadata.
   - Iterates over `state["llm_calls"]` and calls `observability.record_llm_call()` for each, with `call_order` starting at 1.
   - Logs an observability trace event confirming persistence (or the error if it failed).

### Observability Tab in `streamlit_app.py`

A third tab "Observability" (with a magnifying glass icon) provides four sections:

**Section 1: LLM Cost Summary**
- Five KPI metric cards: Total LLM calls, Total tokens, Prompt tokens, Completion tokens, Total LLM time (ms).
- A breakdown table grouped by call type and backend, showing per-group token sums, call counts, and average latency.

**Section 2: Recent Agent Runs**
- A table of the last 50 runs with: Run ID (truncated), timestamp, question, role, category/department filter, duration, and trace event count.

**Section 3: Detailed Run Trace**
- A dropdown to select any recent run.
- Four metric cards for the selected run: total duration, trace event count, role, category filter.
- **Agent pipeline trace table** -- every trace event with timestamp, agent node name, and event message, showing the full step-by-step execution path.
- **LLM call details table** -- each LLM call within the run with call order, type, backend, model, prompt/completion/total tokens, duration, and timestamp.
- The full response text and recommended action for the selected run.

**Section 4: Recent LLM Calls**
- A flat timeline of the 20 most recent individual LLM calls across all runs, with time, call type, backend, model, total tokens, and duration.

### Observability Data Flow Diagram

```
agents.ask(question, role, session_id)
  |
  +---> app_graph.invoke(state)
  |       |
  |       +---> orchestrator
  7       |       +---> model_client.route_intent() -> updates last_call_info
  |       |       +---> state["llm_calls"].append({call_type: "routing", ...})
  |       |
  |       +---> action_agent
  |               +---> model_client.generate() -> updates last_call_info
  |               +---> state["llm_calls"].append({call_type: "generation", ...})
  |
  +---> observability.record_run(...)
  |       -> agent_runs table (run_id, trace_json, metadata)
  |
  +---> for each call in state["llm_calls"]:
  |       observability.record_llm_call(...)
  |       -> llm_calls table (run_id, call_type, backend, tokens, duration)
  |
  v
streamlit_app.py: Observability tab
  |
  +---> observability.get_llm_summary()  -> cost KPIs + breakdown table
  +---> observability.get_recent_runs()  -> runs table
  +---> observability.get_run_trace(run_id)     -> step-by-step trace
  +---> observability.get_llm_calls_for_run(run_id) -> per-call details
```
