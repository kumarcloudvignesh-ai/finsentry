"""
Observability store for FinSentry -- persists every agent pipeline run
and each LLM call within it, so the Observability tab can show:

  - Recent runs (question, timestamp, duration, backend, token totals)
  - Step-by-step agent trace for any selected run
  - LLM cost summary (tokens by backend, by call type, over time)

Storage modes (checked in priority order):
  1. Databricks Unity Catalog -- when DATABRICKS_HTTP_PATH is set, writes to
     Delta tables in {CATALOG}.{SCHEMA} via the Databricks SDK statement
     execution API (same pattern as data_access.py).
  2. Databricks Lakebase -- when LAKEBASE_CONNECTION_STRING is set, writes to
     managed Postgres.
  3. Local SQLite -- default for development (finsentry_observability.db).

Tables:
  agent_runs   -- one row per agents.ask() invocation
  llm_calls    -- one row per LLM call (routing, generation, etc.) within a run
"""

import json
import logging
import os
import sqlite3
import time
import uuid

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Mode detection (priority: UC > Lakebase > SQLite)
# ---------------------------------------------------------------------------
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_HTTP_PATH")
USE_DATABRICKS = bool(DATABRICKS_HTTP_PATH)

LAKEBASE_DSN = os.environ.get("LAKEBASE_CONNECTION_STRING")

CATALOG = os.environ.get("FINSENTRY_CATALOG", "finsentry")
SCHEMA = os.environ.get("FINSENTRY_SCHEMA", "spend_analytics")
RUNS_TABLE = f"{CATALOG}.{SCHEMA}.agent_observability_runs"
LLM_CALLS_TABLE = f"{CATALOG}.{SCHEMA}.agent_observability_llm_calls"

_DATA_DIR = os.environ.get("FINSENTRY_DATA_DIR", "/Workspace/Users/decidrix@gmail.com/finsentry/data")
if os.path.exists(_DATA_DIR):
    LOCAL_DB_PATH = os.path.join(_DATA_DIR, "finsentry_observability.db")
else:
    LOCAL_DB_PATH = "/tmp/finsentry_observability.db"

# ---------------------------------------------------------------------------
# SQLite / Lakebase schema (used by non-UC modes)
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS agent_runs (
    run_id TEXT PRIMARY KEY,
    session_id TEXT,
    ts DOUBLE PRECISION,
    question TEXT,
    role TEXT,
    category_filter TEXT,
    department_filter TEXT,
    response TEXT,
    recommended_action TEXT,
    total_duration_ms REAL,
    num_trace_events INTEGER,
    trace_json TEXT
);
CREATE TABLE IF NOT EXISTS llm_calls (
    id INTEGER PRIMARY KEY {autoincrement},
    run_id TEXT,
    call_order INTEGER,
    call_type TEXT,
    backend TEXT,
    model TEXT,
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    total_tokens INTEGER,
    duration_ms REAL,
    ts DOUBLE PRECISION
);
"""

# ---------------------------------------------------------------------------
# Unity Catalog helpers
# ---------------------------------------------------------------------------
_uc_tables_ensured = False


def _sql_escape(val) -> str:
    """Escape a Python value for a SQL string literal (Databricks SQL)."""
    if val is None:
        return "NULL"
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    s = str(val).replace("\\", "\\\\").replace("'", "''")
    return f"'{s}'"


def _execute_databricks(statement: str) -> list:
    """Execute a SQL statement via Databricks SDK statement execution.

    Returns a list of dicts for SELECT, or an empty list for DDL/DML.
    """
    from databricks.sdk import WorkspaceClient

    w = WorkspaceClient()
    warehouse_id = DATABRICKS_HTTP_PATH.split("/")[-1] if DATABRICKS_HTTP_PATH else None
    result = w.statement_execution.execute_statement(
        statement=statement,
        warehouse_id=warehouse_id,
    )
    if result.result and result.result.data_array:
        columns = [col.name for col in result.manifest.schema.columns]
        return [dict(zip(columns, row)) for row in result.result.data_array]
    return []


def _ensure_uc_tables():
    """Create UC tables on first use."""
    global _uc_tables_ensured
    if _uc_tables_ensured:
        return
    _execute_databricks(
        f"CREATE TABLE IF NOT EXISTS {RUNS_TABLE} ("
        f"  run_id STRING,"
        f"  session_id STRING,"
        f"  ts DOUBLE,"
        f"  question STRING,"
        f"  role STRING,"
        f"  category_filter STRING,"
        f"  department_filter STRING,"
        f"  response STRING,"
        f"  recommended_action STRING,"
        f"  total_duration_ms DOUBLE,"
        f"  num_trace_events INT,"
        f"  trace_json STRING"
        f") USING DELTA"
    )
    _execute_databricks(
        f"CREATE TABLE IF NOT EXISTS {LLM_CALLS_TABLE} ("
        f"  id STRING,"
        f"  run_id STRING,"
        f"  call_order INT,"
        f"  call_type STRING,"
        f"  backend STRING,"
        f"  model STRING,"
        f"  prompt_tokens INT,"
        f"  completion_tokens INT,"
        f"  total_tokens INT,"
        f"  duration_ms DOUBLE,"
        f"  ts DOUBLE"
        f") USING DELTA"
    )
    _uc_tables_ensured = True


# ---------------------------------------------------------------------------
# Connection helper for SQLite / Lakebase modes
# ---------------------------------------------------------------------------
def _get_conn():
    if LAKEBASE_DSN:
        import psycopg2
        conn = psycopg2.connect(LAKEBASE_DSN)
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute(SCHEMA.format(autoincrement="GENERATED ALWAYS AS IDENTITY"))
        return conn, "postgres"
    else:
        conn = sqlite3.connect(LOCAL_DB_PATH)
        conn.executescript(SCHEMA.format(autoincrement="AUTOINCREMENT"))
        conn.commit()
        return conn, "sqlite"


def record_run(
    session_id: str,
    question: str,
    role: str,
    category_filter: str,
    department_filter: str,
    response: str,
    recommended_action: str,
    total_duration_ms: float,
    trace_events: list,
) -> str:
    """Persist a completed agent run. Returns the run_id."""
    run_id = str(uuid.uuid4())
    ts = time.time()
    trace_json = json.dumps(trace_events)

    if USE_DATABRICKS:
        _ensure_uc_tables()
        _execute_databricks(
            f"INSERT INTO {RUNS_TABLE} "
            f"(run_id, session_id, ts, question, role, category_filter, department_filter, "
            f"response, recommended_action, total_duration_ms, num_trace_events, trace_json) "
            f"VALUES ({_sql_escape(run_id)}, {_sql_escape(session_id)}, {ts}, "
            f"{_sql_escape(question)}, {_sql_escape(role)}, "
            f"{_sql_escape(category_filter)}, {_sql_escape(department_filter)}, "
            f"{_sql_escape(response)}, {_sql_escape(recommended_action)}, "
            f"{total_duration_ms}, {len(trace_events)}, {_sql_escape(trace_json)})"
        )
        return run_id

    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = (
        f"INSERT INTO agent_runs "
        f"(run_id, session_id, ts, question, role, category_filter, department_filter, "
        f"response, recommended_action, total_duration_ms, num_trace_events, trace_json) "
        f"VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"
    )
    params = (
        run_id, session_id, ts, question, role,
        category_filter, department_filter,
        response, recommended_action,
        total_duration_ms, len(trace_events),
        trace_json,
    )
    with conn:
        if kind == "postgres":
            with conn.cursor() as cur:
                cur.execute(query, params)
        else:
            conn.execute(query, params)
    if kind == "sqlite":
        conn.close()
    return run_id


def record_llm_call(
    run_id: str,
    call_order: int,
    call_type: str,
    backend: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
    duration_ms: float,
):
    """Persist a single LLM call associated with a run."""
    ts = time.time()

    if USE_DATABRICKS:
        _ensure_uc_tables()
        call_id = str(uuid.uuid4())
        _execute_databricks(
            f"INSERT INTO {LLM_CALLS_TABLE} "
            f"(id, run_id, call_order, call_type, backend, model, "
            f"prompt_tokens, completion_tokens, total_tokens, duration_ms, ts) "
            f"VALUES ({_sql_escape(call_id)}, {_sql_escape(run_id)}, {call_order}, "
            f"{_sql_escape(call_type)}, {_sql_escape(backend)}, {_sql_escape(model)}, "
            f"{prompt_tokens}, {completion_tokens}, {total_tokens}, {duration_ms}, {ts})"
        )
        return

    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = (
        f"INSERT INTO llm_calls "
        f"(run_id, call_order, call_type, backend, model, prompt_tokens, completion_tokens, total_tokens, duration_ms, ts) "
        f"VALUES ({ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph},{ph})"
    )
    params = (run_id, call_order, call_type, backend, model,
              prompt_tokens, completion_tokens, total_tokens, duration_ms, ts)
    with conn:
        if kind == "postgres":
            with conn.cursor() as cur:
                cur.execute(query, params)
        else:
            conn.execute(query, params)
    if kind == "sqlite":
        conn.close()


def get_recent_runs(limit: int = 50) -> list:
    """Return recent agent runs as a list of dicts, newest first."""
    if USE_DATABRICKS:
        _ensure_uc_tables()
        rows = _execute_databricks(
            f"SELECT run_id, session_id, ts, question, role, category_filter, "
            f"department_filter, response, recommended_action, total_duration_ms, "
            f"num_trace_events FROM {RUNS_TABLE} ORDER BY ts DESC LIMIT {limit}"
        )
        return rows

    conn, kind = _get_conn()
    query = (
        "SELECT run_id, session_id, ts, question, role, category_filter, "
        "department_filter, response, recommended_action, total_duration_ms, "
        "num_trace_events FROM agent_runs ORDER BY ts DESC LIMIT ?"
        if kind == "sqlite" else
        "SELECT run_id, session_id, ts, question, role, category_filter, "
        "department_filter, response, recommended_action, total_duration_ms, "
        "num_trace_events FROM agent_runs ORDER BY ts DESC LIMIT %s"
    )
    ph = "%s" if kind == "postgres" else "?"
    query = query.replace("?", ph, 1) if kind == "postgres" else query
    if kind == "postgres":
        with conn.cursor() as cur:
            cur.execute(query, (limit,))
            rows = cur.fetchall()
    else:
        rows = conn.execute(query, (limit,)).fetchall()
        conn.close()
    cols = ["run_id", "session_id", "ts", "question", "role", "category_filter",
            "department_filter", "response", "recommended_action", "total_duration_ms",
            "num_trace_events"]
    return [dict(zip(cols, r)) for r in rows]


def get_run_trace(run_id: str) -> list:
    """Return the full trace events JSON for a specific run."""
    if USE_DATABRICKS:
        _ensure_uc_tables()
        rows = _execute_databricks(
            f"SELECT trace_json FROM {RUNS_TABLE} WHERE run_id = {_sql_escape(run_id)}"
        )
        return json.loads(rows[0]["trace_json"]) if rows else []

    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = f"SELECT trace_json FROM agent_runs WHERE run_id={ph}"
    if kind == "postgres":
        with conn.cursor() as cur:
            cur.execute(query, (run_id,))
            row = cur.fetchone()
    else:
        row = conn.execute(query, (run_id,)).fetchone()
        conn.close()
    return json.loads(row[0]) if row else []


def get_llm_calls_for_run(run_id: str) -> list:
    """Return all LLM calls for a specific run, ordered by call_order."""
    if USE_DATABRICKS:
        _ensure_uc_tables()
        return _execute_databricks(
            f"SELECT call_order, call_type, backend, model, prompt_tokens, "
            f"completion_tokens, total_tokens, duration_ms, ts "
            f"FROM {LLM_CALLS_TABLE} WHERE run_id = {_sql_escape(run_id)} "
            f"ORDER BY call_order"
        )

    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = (
        f"SELECT call_order, call_type, backend, model, prompt_tokens, "
        f"completion_tokens, total_tokens, duration_ms, ts "
        f"FROM llm_calls WHERE run_id={ph} ORDER BY call_order"
    )
    if kind == "postgres":
        with conn.cursor() as cur:
            cur.execute(query, (run_id,))
            rows = cur.fetchall()
    else:
        rows = conn.execute(query, (run_id,)).fetchall()
        conn.close()
    cols = ["call_order", "call_type", "backend", "model", "prompt_tokens",
            "completion_tokens", "total_tokens", "duration_ms", "ts"]
    return [dict(zip(cols, r)) for r in rows]


def get_llm_summary(limit: int = 100) -> dict:
    """Aggregate LLM usage stats across recent runs.
    Returns dict with totals, by_backend, by_call_type, recent_calls."""
    if USE_DATABRICKS:
        _ensure_uc_tables()
        # Grouped breakdown
        breakdown_rows = _execute_databricks(
            f"SELECT call_type, backend, model, "
            f"SUM(prompt_tokens) as sum_prompt, SUM(completion_tokens) as sum_completion, "
            f"SUM(total_tokens) as sum_total, COUNT(*) as num_calls, "
            f"AVG(duration_ms) as avg_duration_ms "
            f"FROM {LLM_CALLS_TABLE} GROUP BY call_type, backend, model "
            f"ORDER BY sum_total DESC LIMIT {limit}"
        )
        by_type_backend = [
            {
                "call_type": r["call_type"], "backend": r["backend"], "model": r["model"],
                "prompt_tokens": int(r["sum_prompt"]) if r["sum_prompt"] else 0,
                "completion_tokens": int(r["sum_completion"]) if r["sum_completion"] else 0,
                "total_tokens": int(r["sum_total"]) if r["sum_total"] else 0,
                "num_calls": int(r["num_calls"]) if r["num_calls"] else 0,
                "avg_duration_ms": round(float(r["avg_duration_ms"]) if r["avg_duration_ms"] else 0, 1),
            }
            for r in breakdown_rows
        ]
        # Overall totals
        total_rows = _execute_databricks(
            f"SELECT COUNT(*) as cnt, SUM(prompt_tokens) as sp, SUM(completion_tokens) as sc, "
            f"SUM(total_tokens) as st, SUM(duration_ms) as sd FROM {LLM_CALLS_TABLE}"
        )
        trow = total_rows[0] if total_rows else {}
        # Recent calls
        recent_rows = _execute_databricks(
            f"SELECT ts, run_id, call_type, backend, model, total_tokens, duration_ms "
            f"FROM {LLM_CALLS_TABLE} ORDER BY ts DESC LIMIT {limit}"
        )
        recent_calls = [
            {"ts": float(r["ts"]) if r["ts"] else 0,
             "run_id": r["run_id"],
             "call_type": r["call_type"],
             "backend": r["backend"],
             "model": r["model"],
             "total_tokens": int(r["total_tokens"]) if r["total_tokens"] else 0,
             "duration_ms": round(float(r["duration_ms"]) if r["duration_ms"] else 0, 1)}
            for r in recent_rows
        ]
        return {
            "total_calls": int(trow.get("cnt", 0)) if trow.get("cnt") else 0,
            "total_prompt_tokens": int(trow.get("sp", 0)) if trow.get("sp") else 0,
            "total_completion_tokens": int(trow.get("sc", 0)) if trow.get("sc") else 0,
            "total_tokens": int(trow.get("st", 0)) if trow.get("st") else 0,
            "total_duration_ms": round(float(trow.get("sd", 0)) if trow.get("sd") else 0, 1),
            "by_type_backend": by_type_backend,
            "recent_calls": recent_calls,
        }

    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = (
        f"SELECT call_type, backend, model, "
        f"SUM(prompt_tokens) as sum_prompt, SUM(completion_tokens) as sum_completion, "
        f"SUM(total_tokens) as sum_total, COUNT(*) as num_calls, "
        f"AVG(duration_ms) as avg_duration_ms "
        f"FROM llm_calls GROUP BY call_type, backend, model "
        f"ORDER BY sum_total DESC LIMIT {ph}"
    )
    if kind == "postgres":
        with conn.cursor() as cur:
            cur.execute(query, (limit,))
            rows = cur.fetchall()
    else:
        rows = conn.execute(query, (limit,)).fetchall()
        conn.close()
    by_type_backend = []
    for r in rows:
        by_type_backend.append({
            "call_type": r[0], "backend": r[1], "model": r[2],
            "prompt_tokens": r[3] or 0, "completion_tokens": r[4] or 0,
            "total_tokens": r[5] or 0, "num_calls": r[6] or 0,
            "avg_duration_ms": round(r[7] or 0, 1),
        })

    # Overall totals
    conn2, kind2 = _get_conn()
    total_query = (
        "SELECT COUNT(*), SUM(prompt_tokens), SUM(completion_tokens), "
        "SUM(total_tokens), SUM(duration_ms) FROM llm_calls"
    )
    if kind2 == "postgres":
        with conn2.cursor() as cur:
            cur.execute(total_query)
            trow = cur.fetchone()
    else:
        trow = conn2.execute(total_query).fetchone()
        conn2.close()

    # Recent individual calls for the timeline
    conn3, kind3 = _get_conn()
    recent_query = (
        f"SELECT ts, run_id, call_type, backend, model, total_tokens, duration_ms "
        f"FROM llm_calls ORDER BY ts DESC LIMIT {ph}"
    )
    if kind3 == "postgres":
        with conn3.cursor() as cur:
            cur.execute(recent_query, (limit,))
            rrows = cur.fetchall()
    else:
        rrows = conn3.execute(recent_query, (limit,)).fetchall()
        conn3.close()
    recent_calls = [
        {"ts": r[0], "run_id": r[1], "call_type": r[2], "backend": r[3],
         "model": r[4], "total_tokens": r[5] or 0, "duration_ms": round(r[6] or 0, 1)}
        for r in rrows
    ]

    return {
        "total_calls": trow[0] or 0,
        "total_prompt_tokens": trow[1] or 0,
        "total_completion_tokens": trow[2] or 0,
        "total_tokens": trow[3] or 0,
        "total_duration_ms": round(trow[4] or 0, 1),
        "by_type_backend": by_type_backend,
        "recent_calls": recent_calls,
    }


def backend_label() -> str:
    if USE_DATABRICKS:
        return f"Unity Catalog Delta ({RUNS_TABLE.split('.')[0]}.{RUNS_TABLE.split('.')[1]})"
    if LAKEBASE_DSN:
        return "Databricks Lakebase (Postgres)"
    return f"local SQLite ({LOCAL_DB_PATH})"
