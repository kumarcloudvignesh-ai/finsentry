"""
Conversation memory for the Action Agent -- the "Lakebase" box in the
architecture diagram.

  - Databricks mode: Lakebase is Databricks' managed Postgres for agent
    state/memory. Set LAKEBASE_CONNECTION_STRING (a standard Postgres DSN --
    inside a Databricks App deployed with a Lakebase resource attached,
    Databricks injects these connection details for you automatically; see
    docs/README_DEPLOY.md). We use plain psycopg2 here for clarity; for
    production LangGraph deployments, swap this for
    `langgraph-checkpoint-postgres` so LangGraph manages checkpointing
    natively against the same Lakebase instance.
  - Local mode: a SQLite file (finsentry_memory.db) with the same two tables,
    so the agent has real short-term + long-term memory while you develop
    without needing a Postgres instance.
"""

import json
import os
import sqlite3
import time

LAKEBASE_DSN = os.environ.get("LAKEBASE_CONNECTION_STRING")
# Use FINSENTRY_DATA_DIR for SQLite if set and writable, else /tmp for Apps
_DATA_DIR = os.environ.get("FINSENTRY_DATA_DIR", "/Workspace/Users/decidrix@gmail.com/finsentry/data")
if os.path.exists(_DATA_DIR):
    LOCAL_DB_PATH = os.path.join(_DATA_DIR, "finsentry_memory.db")
else:
    # Running in Databricks App container - use /tmp which is writable
    LOCAL_DB_PATH = "/tmp/finsentry_memory.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS episodic_memory (
    id INTEGER PRIMARY KEY {autoincrement},
    session_id TEXT,
    ts DOUBLE PRECISION,
    question TEXT,
    analysis TEXT,
    response TEXT
);
CREATE TABLE IF NOT EXISTS semantic_memory (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


def _get_conn():
    if LAKEBASE_DSN:
        import psycopg2

        conn = psycopg2.connect(LAKEBASE_DSN)
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute(SCHEMA.format(autoincrement="GENERATED ALWAYS AS IDENTITY"))
        return conn, "postgres"
    else:
        conn = sqlite3.connect(LOCAL_DB_PATH)
        conn.executescript(SCHEMA.format(autoincrement="AUTOINCREMENT"))
        conn.commit()
        return conn, "sqlite"


def record_event(session_id: str, question: str, analysis: str, response: str):
    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = f"INSERT INTO episodic_memory (session_id, ts, question, analysis, response) VALUES ({ph},{ph},{ph},{ph},{ph})"
    with conn:
        if kind == "postgres":
            with conn.cursor() as cur:
                cur.execute(query, (session_id, time.time(), question, analysis, response))
        else:
            conn.execute(query, (session_id, time.time(), question, analysis, response))
    if kind == "sqlite":
        conn.close()


def recent_events(session_id: str, limit: int = 5):
    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = f"SELECT question, response, ts FROM episodic_memory WHERE session_id={ph} ORDER BY ts DESC LIMIT {ph}"
    if kind == "postgres":
        with conn.cursor() as cur:
            cur.execute(query, (session_id, limit))
            rows = cur.fetchall()
    else:
        rows = conn.execute(query, (session_id, limit)).fetchall()
        conn.close()
    return [{"question": r[0], "response": r[1], "ts": r[2]} for r in rows]


def remember(key: str, value):
    conn, kind = _get_conn()
    payload = json.dumps(value)
    if kind == "postgres":
        with conn, conn.cursor() as cur:
            cur.execute(
                "INSERT INTO semantic_memory (key, value) VALUES (%s,%s) "
                "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
                (key, payload),
            )
    else:
        with conn:
            conn.execute(
                "INSERT INTO semantic_memory (key, value) VALUES (?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, payload),
            )
        conn.close()


def recall(key: str, default=None):
    conn, kind = _get_conn()
    ph = "%s" if kind == "postgres" else "?"
    query = f"SELECT value FROM semantic_memory WHERE key={ph}"
    if kind == "postgres":
        with conn.cursor() as cur:
            cur.execute(query, (key,))
            row = cur.fetchone()
    else:
        row = conn.execute(query, (key,)).fetchone()
        conn.close()
    return json.loads(row[0]) if row else default


def backend_label() -> str:
    return "Databricks Lakebase (Postgres)" if LAKEBASE_DSN else f"local SQLite ({LOCAL_DB_PATH})"
