"""
Data access layer -- reads the 5 Gold tables.

Two modes, chosen automatically:
  - APP_ENV=databricks (or DATABRICKS_HOST/HTTP_PATH/TOKEN are set):
        queries Unity Catalog Gold tables through a Databricks SQL Warehouse
        via the `databricks-sql-connector`.
  - otherwise (default, local dev):
        reads the parquet files written by pipeline/local_pipeline_demo.py.

Both the Streamlit dashboard and the Data Agent import this module, so there
is exactly one place that knows where the data actually lives.
"""

import os
import pandas as pd

BASE = os.environ.get("FINSENTRY_DATA_DIR", "/Workspace/Users/decidrix@gmail.com/finsentry/")
LOCAL_GOLD = os.path.join(BASE, "data", "gold")

DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_HTTP_PATH")  # SQL warehouse HTTP path
CATALOG = os.environ.get("FINSENTRY_CATALOG", "finsentry")
SCHEMA = os.environ.get("FINSENTRY_SCHEMA", "spend_analytics")

# Use Databricks mode if HTTP_PATH is set (SDK will auto-detect host and credentials)
USE_DATABRICKS = bool(DATABRICKS_HTTP_PATH)

# Whitelist of allowed Gold table names -- prevents SQL injection by validating
# the table parameter before it reaches any SQL string.
ALLOWED_TABLES = frozenset({
    "gold_spend_by_category_month",
    "gold_spend_by_vendor",
    "gold_budget_variance",
    "gold_maverick_spend",
    "gold_savings_opportunities",
    "gold_finance_documents",
})


def _query_databricks(table: str) -> pd.DataFrame:
    """Query Unity Catalog tables using Spark SQL via Databricks SDK.
    
    This uses the Databricks SDK which handles OAuth authentication automatically
    in Databricks Apps, avoiding the need for manual tokens.
    """
    from databricks.sdk import WorkspaceClient
    import sys
    
    try:
        # WorkspaceClient auto-detects credentials in Apps (OAuth)
        w = WorkspaceClient()
        
        # Execute SQL using Databricks SDK statement execution
        # This automatically inherits the app's service principal identity
        warehouse_id = DATABRICKS_HTTP_PATH.split("/")[-1] if DATABRICKS_HTTP_PATH else None
        query = f"SELECT * FROM {CATALOG}.{SCHEMA}.{table}"
        
        result = w.statement_execution.execute_statement(
            statement=query,
            warehouse_id=warehouse_id
        )
        
        print(f"DEBUG {table}: result.result={result.result is not None}", file=sys.stderr, flush=True)
        if result.result:
            print(f"DEBUG {table}: data_array={result.result.data_array is not None}, len={len(result.result.data_array) if result.result.data_array else 0}", file=sys.stderr, flush=True)
        
        # Convert result to pandas DataFrame
        if result.result and result.result.data_array is not None and len(result.result.data_array) > 0:
            columns = [col.name for col in result.manifest.schema.columns]
            column_types = {col.name: col.type_name for col in result.manifest.schema.columns}
            
            print(f"DEBUG {table}: {len(columns)} cols = {columns}", file=sys.stderr, flush=True)
            
            # SDK returns rows as plain lists of strings - convert using schema metadata
            rows = []
            for row in result.result.data_array:
                # row is already a plain list of string values
                row_data = []
                for i, val in enumerate(row):
                    col_name = columns[i]
                    col_type = column_types.get(col_name)
                    
                    # Convert based on column type from manifest
                    if val is None or val == '':
                        row_data.append(None)
                    elif 'INT' in str(col_type) or 'LONG' in str(col_type):
                        try:
                            row_data.append(int(val))
                        except (ValueError, TypeError):
                            row_data.append(None)
                    elif 'DOUBLE' in str(col_type) or 'FLOAT' in str(col_type) or 'DECIMAL' in str(col_type):
                        try:
                            row_data.append(float(val))
                        except (ValueError, TypeError):
                            row_data.append(None)
                    elif 'BOOL' in str(col_type):
                        row_data.append(val.lower() in ['true', '1', 'yes'])
                    elif 'DATE' in str(col_type) or 'TIMESTAMP' in str(col_type):
                        # Convert date/timestamp strings to pandas datetime
                        try:
                            row_data.append(pd.to_datetime(val))
                        except (ValueError, TypeError):
                            row_data.append(val)  # Keep as string if conversion fails
                    else:
                        # Keep as string for other types
                        row_data.append(val)
                rows.append(row_data)
            
            df = pd.DataFrame(rows, columns=columns)
            print(f"DEBUG {table}: DataFrame shape={df.shape} cols={list(df.columns)}", file=sys.stderr, flush=True)
            return df
        else:
            print(f"DEBUG {table}: No data returned", file=sys.stderr, flush=True)
            return pd.DataFrame()
    except Exception as e:
        print(f"ERROR {table}: {e}", file=sys.stderr, flush=True)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return pd.DataFrame()


def _read_local(table: str) -> pd.DataFrame:
    path = os.path.join(LOCAL_GOLD, f"{table}.parquet")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Run pipeline/local_pipeline_demo.py first to build the local Gold layer."
        )
    return pd.read_parquet(path)


def get_table(table: str) -> pd.DataFrame:
    """Return a Gold table as a DataFrame. The table name must be in ALLOWED_TABLES."""
    if table not in ALLOWED_TABLES:
        raise ValueError(f"Unknown table '{table}'. Allowed: {sorted(ALLOWED_TABLES)}")
    return _query_databricks(table) if USE_DATABRICKS else _read_local(table)


# ---------------------------------------------------------------------------
# Convenience accessors used by the agents + the Streamlit dashboard
# ---------------------------------------------------------------------------
def spend_by_category_month() -> pd.DataFrame:
    return get_table("gold_spend_by_category_month")


def spend_by_vendor() -> pd.DataFrame:
    return get_table("gold_spend_by_vendor")


def budget_variance() -> pd.DataFrame:
    return get_table("gold_budget_variance")


def maverick_spend() -> pd.DataFrame:
    return get_table("gold_maverick_spend")


def savings_opportunities() -> pd.DataFrame:
    return get_table("gold_savings_opportunities")


def data_source_label() -> str:
    return f"Databricks SQL Warehouse ({CATALOG}.{SCHEMA})" if USE_DATABRICKS else "local demo data (data/gold/*.parquet)"
