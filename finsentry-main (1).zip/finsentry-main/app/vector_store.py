"""
Retrieval layer for the RAG Agent.

  - Databricks mode: queries a real Databricks Vector Search Delta Sync index
    (see pipeline/databricks_pipeline.py for how it's built).
  - Local mode: a lightweight TF-IDF search over the same document chunks
    (via data_access.get_table("gold_finance_documents")) -- no extra service
    needed to develop and test the agent's RAG behavior locally.
"""

import logging
import os
from typing import List, Dict

logger = logging.getLogger(__name__)

import data_access

VS_ENDPOINT = os.environ.get("FINSENTRY_VS_ENDPOINT", "finsentry_vs_endpoint")
VS_INDEX = os.environ.get(
    "FINSENTRY_VS_INDEX",
    f"{data_access.CATALOG}.{data_access.SCHEMA}.finance_docs_index",
)

_local_vectorizer = None
_local_matrix = None
_local_docs = None


def _ensure_local_index():
    global _local_vectorizer, _local_matrix, _local_docs
    if _local_vectorizer is not None:
        return
    from sklearn.feature_extraction.text import TfidfVectorizer

    _local_docs = data_access.get_table("gold_finance_documents")
    _local_vectorizer = TfidfVectorizer(stop_words="english")
    _local_matrix = _local_vectorizer.fit_transform(_local_docs["text"].tolist())


def _search_local(query: str, k: int) -> List[Dict]:
    from sklearn.metrics.pairwise import cosine_similarity

    _ensure_local_index()
    query_vec = _local_vectorizer.transform([query])
    scores = cosine_similarity(query_vec, _local_matrix).flatten()
    top_idx = scores.argsort()[::-1][:k]
    return [
        {
            "text": _local_docs.iloc[i]["text"],
            "source": _local_docs.iloc[i]["source_file"],
            "score": float(scores[i]),
        }
        for i in top_idx if scores[i] > 0
    ]


def _search_databricks(query: str, k: int) -> List[Dict]:
    """Search using Vector Search with explicit OAuth token from WorkspaceClient."""
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient

    try:
        # Use WorkspaceClient to get OAuth credentials
        w = WorkspaceClient()
        
        # authenticate() returns a dict of headers; extract the Bearer token
        auth_headers = w.config.authenticate()
        token = auth_headers["Authorization"].replace("Bearer ", "")
        
        # Initialize VectorSearchClient with explicit token
        vsc = VectorSearchClient(
            workspace_url=w.config.host,
            personal_access_token=token,
            disable_notice=True
        )
        
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=VS_INDEX)
        results = index.similarity_search(
            query_text=query, columns=["text", "source_file"], num_results=k
        )
        hits = results.get("result", {}).get("data_array", [])
        return [{"text": h[0], "source": h[1], "score": h[-1]} for h in hits]
    except Exception as e:
        # Fall back to local search if Vector Search fails
        logger.warning("Vector Search failed (%s), falling back to local TF-IDF search", e)
        return _search_local(query, k)


def search(query: str, k: int = 3) -> List[Dict]:
    if data_access.USE_DATABRICKS:
        return _search_databricks(query, k)
    return _search_local(query, k)
