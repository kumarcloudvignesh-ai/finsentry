"""
FinSentry -- Spend Intelligence & Conversational AI (Streamlit)

Three tabs:
  1. Spend Overview   -- KPIs, spend by category, top vendors, savings
                           opportunities, budget alerts (reads Gold tables
                           via data_access.py)
  2. Ask FinSentry    -- conversational chat backed by the LangGraph agent
                           pipeline in agents.py
  3. Observability    -- agent pipeline traces, LLM call details, token usage
                           and cost summary (reads from observability.py)

Deploy as-is to Databricks Apps (see app.yaml + requirements.txt in this
folder, and docs/README_DEPLOY.md for the full walkthrough). Runs locally
with `streamlit run streamlit_app.py` against the local demo data with no
extra setup.
"""

import streamlit as st
import pandas as pd

import data_access
import agents
import model_client
import memory_store
import observability

st.set_page_config(page_title="FinSentry -- NorthBridge Industries", page_icon="\U0001F4CA", layout="wide")

# ---------------------------------------------------------------------------
# Sidebar -- role selector (drives the Unity-Catalog-style permission gate)
# ---------------------------------------------------------------------------
with st.sidebar:
    st.title("FinSentry")
    st.caption("Spend Intelligence & Conversational AI for NorthBridge Industries")
    role = st.selectbox("Signed in as", ["analyst", "exec"], help="Controls which categories the agent will discuss.")
    st.divider()
    st.caption("**Connected services**")
    st.text(f"Data:   {data_access.data_source_label()}")
    st.text(f"Model:  {model_client.active_backend()}")
    st.text(f"Memory: {memory_store.backend_label()}")
    st.text(f"Obs:    {observability.backend_label()}")

tab_dashboard, tab_chat, tab_observability = st.tabs(["\U0001F4CA Spend Overview", "\U0001F4AC Ask FinSentry", "\U0001F50E Observability"])

# ---------------------------------------------------------------------------
# Cached data loaders -- avoid re-querying on every Streamlit rerun
# ---------------------------------------------------------------------------
@st.cache_data(ttl=300)
def _load_dashboard_data():
    return {
        "cat_month": data_access.spend_by_category_month(),
        "vendors": data_access.spend_by_vendor(),
        "budget": data_access.budget_variance(),
        "maverick": data_access.maverick_spend(),
        "savings": data_access.savings_opportunities(),
    }

# ---------------------------------------------------------------------------
# Tab 1: Spend Overview
# ---------------------------------------------------------------------------
with tab_dashboard:
    data = _load_dashboard_data()
    cat_month = data["cat_month"]
    vendors = data["vendors"]
    budget = data["budget"]
    maverick = data["maverick"]
    savings = data["savings"]

    total_spend = cat_month["total_spend"].sum()
    total_savings_potential = savings["estimated_annual_savings"].sum()
    overrun_months = (budget["variance_pct"] > 8).sum()
    
    # Handle division by zero gracefully
    maverick_total = maverick["total_spend"].sum()
    if maverick_total > 0:
        maverick_pct = maverick["no_po_spend"].sum() / maverick_total * 100
    else:
        maverick_pct = 0.0

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Total spend (24 mo)", f"${total_spend:,.0f}")
    k2.metric("Identified savings potential", f"${total_savings_potential:,.0f}/yr")
    k3.metric("Dept-months over budget (>8%)", f"{overrun_months}")
    k4.metric("Spend without a PO", f"{maverick_pct:.0f}%")

    st.divider()
    col1, col2 = st.columns([3, 2])

    with col1:
        st.subheader("Monthly spend by category")
        pivot = cat_month.pivot_table(index="month", columns="category_name", values="total_spend", aggfunc="sum").fillna(0)
        st.line_chart(pivot)

        st.subheader("Savings opportunities")
        display_savings = savings.sort_values("estimated_annual_savings", ascending=False)[
            ["opportunity_type", "category_name", "description", "estimated_annual_savings"]
        ].rename(columns={
            "opportunity_type": "Type", "category_name": "Category",
            "description": "Finding", "estimated_annual_savings": "Est. annual savings ($)",
        })
        st.dataframe(display_savings, use_container_width=True, hide_index=True)

    with col2:
        st.subheader("Top vendors by spend")
        top_vendors = vendors.sort_values("vendor_spend", ascending=False).head(10)[
            ["vendor_name", "category_name", "vendor_spend", "pct_of_category", "preferred_vendor"]
        ].rename(columns={
            "vendor_name": "Vendor", "category_name": "Category", "vendor_spend": "Spend ($)",
            "pct_of_category": "% of category", "preferred_vendor": "Preferred",
        })
        st.dataframe(top_vendors, use_container_width=True, hide_index=True)

        st.subheader("Recent budget alerts")
        alerts = budget[budget["variance_pct"] > 8].sort_values("variance_pct", ascending=False).head(8)[
            ["department_name", "month", "variance_pct", "variance_amount"]
        ].rename(columns={
            "department_name": "Department", "month": "Month",
            "variance_pct": "Over budget (%)", "variance_amount": "Amount over ($)",
        })
        st.dataframe(alerts, use_container_width=True, hide_index=True)

# ---------------------------------------------------------------------------
# Tab 2: Ask FinSentry (conversational AI)
# ---------------------------------------------------------------------------
with tab_chat:
    st.caption(
        "Ask about spend drivers, budget variance, or savings opportunities. "
        "Answers are grounded in the Gold spend tables and NorthBridge's policy/contract documents."
    )

    if "session_id" not in st.session_state:
        import uuid
        st.session_state.session_id = str(uuid.uuid4())
    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    suggestions = [
        "What's driving our IT & Software spend?",
        "Where can we find savings in MRO Supplies?",
        "Why is Manufacturing Operations over budget?",
    ]
    cols = st.columns(len(suggestions))
    clicked = None
    for c, s in zip(cols, suggestions):
        if c.button(s, use_container_width=True):
            clicked = s

    user_input = st.chat_input("Ask a question about NorthBridge spend...")
    question = clicked or user_input

    if question:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Routing through Orchestrator -> Data -> Analytics -> RAG -> Action..."):
                result = agents.ask(question, role=role, session_id=st.session_state.session_id)
            st.markdown(result["response"])

            with st.expander("How this answer was produced"):
                st.markdown(f"**Recommended action:** {result['recommended_action']}")
                st.markdown("**Retrieved policy/contract context:**")
                for d in result["retrieved_docs"]:
                    st.caption(f"({d['source']}) {d['text'][:200]}...")
                st.markdown("**Agent trace:**")
                for e in result["trace"].events:
                    st.caption(f"`{e['agent']}` {e['msg']}")

        st.session_state.messages.append({"role": "assistant", "content": result["response"]})

# ---------------------------------------------------------------------------
# Tab 3: Observability -- agent pipeline traces + LLM cost details
# ---------------------------------------------------------------------------
with tab_observability:
    st.caption(
        "Every agent pipeline run is persisted with full trace events and LLM call details. "
        "Use this tab to audit how questions were routed, what data was retrieved, and how many tokens each LLM call consumed."
    )

    # -- Section 1: LLM Cost Summary ---------------------------------------
    st.subheader("LLM Cost Summary")

    try:
        llm_summary = observability.get_llm_summary(limit=100)

        total_calls = int(llm_summary["total_calls"]) if llm_summary["total_calls"] else 0
        total_tokens = int(llm_summary["total_tokens"]) if llm_summary["total_tokens"] else 0
        total_prompt = int(llm_summary["total_prompt_tokens"]) if llm_summary["total_prompt_tokens"] else 0
        total_completion = int(llm_summary["total_completion_tokens"]) if llm_summary["total_completion_tokens"] else 0
        total_duration = float(llm_summary["total_duration_ms"]) if llm_summary["total_duration_ms"] else 0.0

        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Total LLM calls", f"{total_calls}")
        c2.metric("Total tokens", f"{total_tokens:,}")
        c3.metric("Prompt tokens", f"{total_prompt:,}")
        c4.metric("Completion tokens", f"{total_completion:,}")
        c5.metric("Total LLM time", f"{total_duration:,.0f} ms")

        if llm_summary["by_type_backend"]:
            st.markdown("**Breakdown by call type and backend:**")
            breakdown_df = pd.DataFrame(llm_summary["by_type_backend"])
            st.dataframe(breakdown_df, use_container_width=True, hide_index=True)
        else:
            st.info("No LLM calls recorded yet. Ask a question in the "
                    '"Ask FinSentry" tab to generate trace data.')

    except Exception as e:
        st.warning(f"Could not load LLM summary: {e}")

    st.divider()

    # -- Section 2: Recent Runs --------------------------------------------
    st.subheader("Recent Agent Runs")

    try:
        recent_runs = observability.get_recent_runs(limit=50)
        if recent_runs:
            runs_df = pd.DataFrame(recent_runs)
            # Format timestamp
            runs_df["timestamp"] = pd.to_datetime(runs_df["ts"], unit="s").dt.strftime("%Y-%m-%d %H:%M:%S")
            runs_df["duration (ms)"] = runs_df["total_duration_ms"].round(1)

            display_df = runs_df[["run_id", "timestamp", "question", "role",
                                   "category_filter", "department_filter",
                                   "duration (ms)", "num_trace_events"]].rename(columns={
                "run_id": "Run ID",
                "question": "Question",
                "role": "Role",
                "category_filter": "Category",
                "department_filter": "Department",
                "num_trace_events": "Trace events",
            })
            display_df["Run ID"] = display_df["Run ID"].str[:8] + "..."
            st.dataframe(display_df, use_container_width=True, hide_index=True)

            # -- Section 3: Detailed Trace for Selected Run --------------------
            st.divider()
            st.subheader("Detailed Run Trace")

            run_options = {f"{r['run_id'][:8]}... | {r['question'][:60]}": r["run_id"] for r in recent_runs}
            selected_label = st.selectbox("Select a run to inspect", list(run_options.keys()))
            selected_run_id = run_options[selected_label]

            if selected_run_id:
                # Show run metadata
                selected_run = next(r for r in recent_runs if r["run_id"] == selected_run_id)
                mc1, mc2, mc3, mc4 = st.columns(4)
                duration_ms = float(selected_run['total_duration_ms']) if selected_run['total_duration_ms'] else 0
                trace_events = int(selected_run['num_trace_events']) if selected_run['num_trace_events'] else 0
                mc1.metric("Total duration", f"{duration_ms:.0f} ms")
                mc2.metric("Trace events", f"{trace_events}")
                mc3.metric("Role", selected_run["role"])
                mc4.metric("Category filter", selected_run["category_filter"] or "(none)")

                # Show agent trace
                st.markdown("**Agent pipeline trace (step by step):**")
                trace_events = observability.get_run_trace(selected_run_id)
                if trace_events:
                    trace_df = pd.DataFrame(trace_events)
                    # Convert timestamp to numeric
                    trace_df["t"] = pd.to_numeric(trace_df["t"], errors="coerce")
                    trace_df["time"] = pd.to_datetime(trace_df["t"], unit="s").dt.strftime("%H:%M:%S.%f").str[:-3]
                    trace_df = trace_df[["time", "agent", "msg"]].rename(columns={
                        "time": "Time",
                        "agent": "Agent node",
                        "msg": "Event",
                    })
                    st.dataframe(trace_df, use_container_width=True, hide_index=True)
                else:
                    st.info("No trace events for this run.")

                # Show LLM call details
                st.markdown("**LLM call details:**")
                llm_calls = observability.get_llm_calls_for_run(selected_run_id)
                if llm_calls:
                    calls_df = pd.DataFrame(llm_calls)
                    # Convert numeric columns from strings to proper types
                    calls_df["ts"] = pd.to_numeric(calls_df["ts"], errors="coerce")
                    calls_df["call_order"] = pd.to_numeric(calls_df["call_order"], errors="coerce").fillna(0).astype(int)
                    calls_df["prompt_tokens"] = pd.to_numeric(calls_df["prompt_tokens"], errors="coerce").fillna(0).astype(int)
                    calls_df["completion_tokens"] = pd.to_numeric(calls_df["completion_tokens"], errors="coerce").fillna(0).astype(int)
                    calls_df["total_tokens"] = pd.to_numeric(calls_df["total_tokens"], errors="coerce").fillna(0).astype(int)
                    calls_df["duration_ms"] = pd.to_numeric(calls_df["duration_ms"], errors="coerce")
                    calls_df["timestamp"] = pd.to_datetime(calls_df["ts"], unit="s").dt.strftime("%H:%M:%S")
                    calls_df = calls_df[["call_order", "call_type", "backend", "model",
                                        "prompt_tokens", "completion_tokens", "total_tokens",
                                        "duration_ms", "timestamp"]].rename(columns={
                        "call_order": "#",
                        "call_type": "Call type",
                        "backend": "Backend",
                        "model": "Model",
                        "prompt_tokens": "Prompt tokens",
                        "completion_tokens": "Completion tokens",
                        "total_tokens": "Total tokens",
                        "duration_ms": "Duration (ms)",
                        "timestamp": "Time",
                    })
                    st.dataframe(calls_df, use_container_width=True, hide_index=True)
                else:
                    st.info("No LLM calls recorded for this run (offline mode or routing fell back to keywords).")

                # Show the response and recommended action
                st.markdown("**Response:**")
                st.text_area("", value=selected_run.get("response", ""), height=150, disabled=True)
                st.markdown(f"**Recommended action:** {selected_run.get('recommended_action', '')}")

        else:
            st.info("No agent runs recorded yet. Ask a question in the "
                    '"Ask FinSentry" tab to generate observability data.')

    except Exception as e:
        st.warning(f"Could not load recent runs: {e}")

    st.divider()

    # -- Section 4: Recent LLM Calls Timeline ------------------------------
    st.subheader("Recent LLM Calls")
    try:
        llm_summary = observability.get_llm_summary(limit=20)
        if llm_summary["recent_calls"]:
            recent_calls_df = pd.DataFrame(llm_summary["recent_calls"])
            recent_calls_df["time"] = pd.to_datetime(recent_calls_df["ts"], unit="s").dt.strftime("%Y-%m-%d %H:%M:%S")
            recent_calls_df = recent_calls_df[["time", "call_type", "backend", "model",
                                              "total_tokens", "duration_ms"]].rename(columns={
                "time": "Time",
                "call_type": "Call type",
                "backend": "Backend",
                "model": "Model",
                "total_tokens": "Total tokens",
                "duration_ms": "Duration (ms)",
            })
            st.dataframe(recent_calls_df, use_container_width=True, hide_index=True)
    except Exception:
        pass
