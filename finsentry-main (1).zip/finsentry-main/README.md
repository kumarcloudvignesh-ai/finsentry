# FinSentry -- Spend Intelligence & Conversational AI

An end-to-end reference implementation of the multi-agent Lakehouse
architecture:

```
Orchestrator -> Data Agent -> Analytics Agent -> RAG Agent -> Action Agent -> Response
```

built for a fictional finance/manufacturing company, **NorthBridge
Industries**, that wants to (1) understand its key spend drivers and
improvement areas and (2) give finance/procurement stakeholders a
conversational AI to ask about it.

## What's here

```
data/
  generate_finance_data.py   Synthetic 24-month spend dataset (5 CSVs)
  raw/                       Generated CSVs
  gold/                      Generated local Gold tables (parquet)
docs/
  policy_procurement.txt              RAG source doc
  vendor_contracts_summary.txt        RAG source doc
  quarterly_spend_narrative_2025q3.txt  RAG source doc
  README_DEPLOY.md            Full Databricks deployment walkthrough
pipeline/
  databricks_pipeline.py     PySpark + Unity Catalog Bronze/Silver/Gold
                              + Vector Search index (run in Databricks)
  local_pipeline_demo.py     pandas mirror of the same logic (run locally)
app/
  data_access.py    Gold tables: local parquet <-> Databricks SQL Warehouse
  vector_store.py   RAG: local TF-IDF <-> Databricks Vector Search
  model_client.py   LLM: offline template <-> Anthropic API <-> Model Serving
  memory_store.py   Memory: local SQLite <-> Databricks Lakebase (Postgres)
  agents.py         The LangGraph multi-agent graph
  streamlit_app.py  The UI (dashboard + chat)
  app.yaml / requirements.txt   Databricks Apps deployment config
```

Every module in `app/` auto-detects its environment: with no configuration
it runs entirely locally (parquet files, TF-IDF search, a templated
"LLM", SQLite); set the relevant environment variables and the exact same
code talks to real Unity Catalog tables, Databricks Vector Search,
Model Serving, and Lakebase -- no code changes, no branching logic in the
app itself.

## Run it locally (5 minutes)

```bash
cd data && python generate_finance_data.py && cd ..
cd pipeline && python local_pipeline_demo.py && cd ..
cd app
pip install -r requirements.txt
python agents.py                      # sanity-check the agent graph in a terminal
streamlit run streamlit_app.py        # the full UI
```

Try asking the chat: *"What's driving our IT & Software spend?"*,
*"Where can we find savings in MRO Supplies?"*, or
*"Why is Manufacturing Operations over budget?"* -- each answer is grounded
in both the structured Gold tables and the retrieved policy/contract text,
and you can expand "How this answer was produced" to see the full agent
trace.

## What the data actually shows

The synthetic dataset isn't random noise -- it encodes specific, findable
patterns so the analytics layer has real signal:

- **IT & Software cost spike**: a SaaS renewal (CoreStack Cloud Platform)
  auto-renewed at a ~55% higher rate in Q3 2025.
- **Vendor concentration risk**: Atlas Metals Supply holds ~65% of Raw
  Materials spend.
- **PO compliance gap**: ~27-28% of IT & Software and Professional Services
  spend bypasses the purchase-order process.
- **Off-contract spend**: MRO Supplies (78%), IT & Software (47%), and
  Travel & Entertainment show heavy non-preferred-vendor spend at a cost
  premium.
- **Vendor fragmentation**: 8-9 overlapping vendors each in MRO Supplies
  and IT & Software with no consolidated national account.
- **Budget overrun**: Manufacturing Operations trends over budget from
  mid-2025 onward, tracing back to Raw Materials cost inflation.

## Deploying to Databricks

See `docs/README_DEPLOY.md` for the full walkthrough: Unity Catalog setup,
running the pipeline as a Workflow, Model Serving, Lakebase provisioning,
Unity Catalog row-level governance, and deploying the Streamlit UI as a
Databricks App.
